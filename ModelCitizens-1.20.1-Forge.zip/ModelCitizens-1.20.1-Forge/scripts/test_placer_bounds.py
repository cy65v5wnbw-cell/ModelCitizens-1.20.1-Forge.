#!/usr/bin/env python3
"""Guard the custom placer against out-of-bounds/world-border placements."""
from __future__ import annotations
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java").read_text(encoding="utf-8")


class PlacerBoundsTests(unittest.TestCase):
    def test_destination_bounds_are_checked_before_target_state(self) -> None:
        bounds_check = SOURCE.index("!level.isInWorldBounds(pos) || !level.getWorldBorder().isWithinBounds(pos)")
        state_read = SOURCE.index("BlockState previousState = level.getBlockState(pos);")
        self.assertLess(bounds_check, state_read)
        self.assertIn("return InteractionResult.FAIL;", SOURCE[bounds_check:state_read])
        self.assertIn("if (!previousState.canBeReplaced()) return InteractionResult.FAIL;", SOURCE[state_read:])

    def test_loaded_chunk_guard_precedes_any_server_destination_read(self) -> None:
        chunk_guard = SOURCE.index("!level.isClientSide && !level.hasChunkAt(pos)")
        state_read = SOURCE.index("BlockState previousState = level.getBlockState(pos);")
        block_entity_access = SOURCE.index("level.getBlockEntity(pos)")
        self.assertLess(chunk_guard, state_read)
        self.assertLess(chunk_guard, block_entity_access)
        self.assertIn("must not force-load or generate chunks", SOURCE)


if __name__ == "__main__":
    unittest.main(verbosity=2)
