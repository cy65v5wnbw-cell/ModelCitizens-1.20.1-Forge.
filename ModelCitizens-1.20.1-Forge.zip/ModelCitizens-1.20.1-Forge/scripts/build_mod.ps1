# Reproducible Windows build entry point. Requires Python 3, JDK 17, and PowerShell.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

python scripts/run_checks.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$Java = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME 'bin\java.exe' } else { 'java.exe' }
$JavaVersion = (& $Java -version 2>&1 | Select-Object -First 1)
if ($LASTEXITCODE -ne 0 -or $JavaVersion -notmatch 'version "17([.]|")') {
    Write-Error "This project targets JDK 17. Detected: $JavaVersion. Install JDK 17 and set JAVA_HOME."
    exit 2
}

$GradleVersion = '8.8'
$CacheRoot = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'ModelCitizens\gradle' } else { Join-Path $HOME '.cache\modelcitizens\gradle' }
$GradleHome = Join-Path $CacheRoot "gradle-$GradleVersion"
$GradleExe = $null
$SystemGradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($SystemGradle) {
    $SystemVersion = (& $SystemGradle.Source --version 2>&1 | Select-String '^Gradle ' | Select-Object -First 1).Line
    if ($SystemVersion -eq "Gradle $GradleVersion") { $GradleExe = $SystemGradle.Source }
    else { Write-Host "Installed Gradle version '$SystemVersion' is not Gradle $GradleVersion; using the pinned distribution." }
}
if (-not $GradleExe) {
    $GradleExe = Join-Path $GradleHome 'bin\gradle.bat'
}
if (-not (Test-Path $GradleExe)) {
    New-Item -ItemType Directory -Force -Path $CacheRoot | Out-Null
    $Zip = Join-Path $CacheRoot "gradle-$GradleVersion-bin.zip"
    $Url = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"
    $ChecksumUrl = "$Url.sha256"
    Write-Host "Gradle not found; downloading official Gradle $GradleVersion distribution..."
    Invoke-WebRequest -Uri $Url -OutFile $Zip
    $Expected = (Invoke-WebRequest -Uri $ChecksumUrl).Content.Trim()
    if ($Expected -notmatch '^[a-fA-F0-9]{64}$') { Remove-Item $Zip -Force; throw 'Invalid Gradle SHA-256 response.' }
    $Actual = (Get-FileHash -Path $Zip -Algorithm SHA256).Hash
    if ($Actual -ne $Expected) { Remove-Item $Zip -Force; throw 'Gradle distribution SHA-256 mismatch; refusing to execute it.' }
    Expand-Archive -Path $Zip -DestinationPath $CacheRoot -Force
}

& $GradleExe --no-daemon --version
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $GradleExe --no-daemon clean build
exit $LASTEXITCODE
