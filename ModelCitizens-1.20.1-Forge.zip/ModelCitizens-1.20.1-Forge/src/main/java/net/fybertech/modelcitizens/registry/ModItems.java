package net.fybertech.modelcitizens.registry;

import net.fybertech.modelcitizens.ModelCitizens;
import net.fybertech.modelcitizens.world.CitizenPlacerItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ModelCitizens.MODID);
    public static final RegistryObject<Item> CITIZEN = ITEMS.register("citizen", () -> new BlockItem(ModBlocks.CITIZEN.get(), new Item.Properties()));
    public static final RegistryObject<Item> PLACER = ITEMS.register("placer", () -> new CitizenPlacerItem(new Item.Properties().stacksTo(1)));
    private ModItems() {}
}
