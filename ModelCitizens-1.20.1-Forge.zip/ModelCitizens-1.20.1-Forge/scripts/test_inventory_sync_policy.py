#!/usr/bin/env python3
"""Regression tests for avoiding redundant full block-entity inventory syncs."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java"


class InventorySyncPolicyTests(unittest.TestCase):
    def setUp(self) -> None:
        self.source = SOURCE.read_text(encoding="utf-8")

    def test_main_inventory_changes_do_not_broadcast_full_block_entity(self) -> None:
        callback = self.source.split("@Override protected void onContentsChanged(int slot)", 1)[1].split("\n        }", 1)[0]
        self.assertIn("setChanged();", callback)
        self.assertIn("if (slot >= MAIN_SIZE) syncToClient();", callback)
        self.assertNotIn("syncToClient();\n        }", callback)

    def test_rendered_slots_are_inside_sync_range(self) -> None:
        renderer = (ROOT / "src/main/java/net/fybertech/modelcitizens/client/CitizenRenderer.java").read_text(encoding="utf-8")
        self.assertIn("be.inventory().getStackInSlot(slot)", renderer)
        self.assertIn("CitizenBlockEntity.HAND_SLOT", renderer)
        self.assertIn("MAIN_SIZE = 36, ARMOR_SIZE = 4, HAND_SLOT = 40, TOTAL_SIZE = 41", self.source)

    def test_loading_still_suppresses_intermediate_syncs(self) -> None:
        self.assertIn("if (!suppressInventorySync && level != null && !level.isClientSide)", self.source)
        self.assertIn("suppressInventorySync = true;", self.source)
        self.assertIn("suppressInventorySync = false;", self.source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
