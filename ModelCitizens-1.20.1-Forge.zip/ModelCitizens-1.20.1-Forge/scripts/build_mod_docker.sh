#!/usr/bin/env bash
# Containerized Forge build for hosts without a local JDK 17 / Gradle install.
# Requires Docker and network access for the image and Forge/Minecraft dependencies.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="gradle:8.8-jdk17"

cd "$ROOT"
command -v python3 >/dev/null 2>&1 || { echo "ERROR: python3 is required for source/resource checks." >&2; exit 2; }
python3 scripts/run_checks.py

command -v docker >/dev/null 2>&1 || {
  echo "ERROR: Docker CLI not found. Install Docker Desktop or Docker Engine, then rerun this script." >&2
  exit 2
}
docker info >/dev/null 2>&1 || {
  echo "ERROR: Docker daemon is not reachable. Start Docker and verify the current user has permission to use it." >&2
  exit 2
}

# Run as the invoking user so the build/libs output remains editable on the host.
# The Gradle cache lives inside the disposable container; dependencies are fetched
# on each run unless Docker/Gradle image layers or a future cache mount are used.
exec docker run --rm \
  --user "$(id -u):$(id -g)" \
  -e GRADLE_USER_HOME=/tmp/modelcitizens-gradle-home \
  -v "$ROOT:/workspace" \
  -w /workspace \
  "$IMAGE" --no-daemon clean build
