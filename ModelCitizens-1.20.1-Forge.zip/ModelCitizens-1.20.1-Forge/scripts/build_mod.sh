#!/usr/bin/env bash
# Reproducible local build entry point for Model Citizens (Minecraft 1.20.1 / Forge 47.3.0).
# Uses Gradle 8.8, bootstrapping the official distribution when Gradle is not installed.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GRADLE_VERSION="8.8"
CACHE_ROOT="${XDG_CACHE_HOME:-${HOME:-/tmp}/.cache}/modelcitizens"
DIST_DIR="$CACHE_ROOT/gradle-$GRADLE_VERSION"
DIST_ZIP="$CACHE_ROOT/gradle-$GRADLE_VERSION-bin.zip"
DIST_URL="https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
CHECKSUM_URL="$DIST_URL.sha256"

cd "$ROOT"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 is required for source/resource checks." >&2
  exit 2
fi

# Run cheap checks before downloading the build tool or Forge dependencies.
python3 scripts/run_checks.py

# ForgeGradle declares Java 17 as its toolchain. Fail early with an actionable
# message rather than letting Gradle fail later with an opaque toolchain error.
JAVA_BIN="${JAVA_HOME:+$JAVA_HOME/bin/}java"
if ! command -v "$JAVA_BIN" >/dev/null 2>&1; then
  echo "ERROR: Java was not found. Install JDK 17 and set JAVA_HOME." >&2
  exit 2
fi
JAVA_VERSION_LINE="$($JAVA_BIN -version 2>&1 | head -n 1)"
if [[ ! "$JAVA_VERSION_LINE" =~ version\ \"17([.]|\") ]]; then
  echo "ERROR: this project targets JDK 17; detected: $JAVA_VERSION_LINE" >&2
  echo "Install JDK 17 and set JAVA_HOME to that installation, then rerun scripts/build_mod.sh." >&2
  exit 2
fi

GRADLE_BIN=""
if command -v gradle >/dev/null 2>&1; then
  SYSTEM_GRADLE="$(command -v gradle)"
  SYSTEM_GRADLE_VERSION="$("$SYSTEM_GRADLE" --version 2>/dev/null | sed -n 's/^Gradle //p' | head -n 1)"
  if [[ "$SYSTEM_GRADLE_VERSION" == "$GRADLE_VERSION" ]]; then
    GRADLE_BIN="$SYSTEM_GRADLE"
  else
    echo "Installed Gradle version '${SYSTEM_GRADLE_VERSION:-unknown}' is not $GRADLE_VERSION; using the pinned distribution."
  fi
fi

if [[ -z "$GRADLE_BIN" ]]; then
  mkdir -p "$CACHE_ROOT"
  if [[ ! -x "$DIST_DIR/bin/gradle" ]]; then
    command -v curl >/dev/null 2>&1 || { echo "ERROR: install curl to bootstrap Gradle $GRADLE_VERSION." >&2; exit 2; }
    command -v unzip >/dev/null 2>&1 || { echo "ERROR: install unzip to bootstrap Gradle $GRADLE_VERSION." >&2; exit 2; }
    echo "Gradle not found; downloading official Gradle $GRADLE_VERSION distribution..."
    curl --fail --location --retry 2 --output "$DIST_ZIP" "$DIST_URL"
    EXPECTED_SHA="$(curl --fail --location --retry 2 "$CHECKSUM_URL" | tr -d '[:space:]')"
    if [[ ! "$EXPECTED_SHA" =~ ^[a-fA-F0-9]{64}$ ]]; then
      echo "ERROR: Gradle distribution checksum endpoint returned an invalid SHA-256." >&2
      rm -f "$DIST_ZIP"
      exit 2
    fi
    ACTUAL_SHA="$(sha256sum "$DIST_ZIP" | awk '{print $1}')"
    if [[ "${ACTUAL_SHA,,}" != "${EXPECTED_SHA,,}" ]]; then
      echo "ERROR: Gradle distribution SHA-256 mismatch; refusing to execute it." >&2
      rm -f "$DIST_ZIP"
      exit 2
    fi
    TMP_DIR="$CACHE_ROOT/.extract-$$"
    rm -rf "$TMP_DIR"
    mkdir -p "$TMP_DIR"
    unzip -q "$DIST_ZIP" -d "$TMP_DIR"
    rm -rf "$DIST_DIR"
    mv "$TMP_DIR/gradle-$GRADLE_VERSION" "$DIST_DIR"
    rm -rf "$TMP_DIR"
  fi
  GRADLE_BIN="$DIST_DIR/bin/gradle"
fi

"$GRADLE_BIN" --no-daemon --version
exec "$GRADLE_BIN" --no-daemon clean build
