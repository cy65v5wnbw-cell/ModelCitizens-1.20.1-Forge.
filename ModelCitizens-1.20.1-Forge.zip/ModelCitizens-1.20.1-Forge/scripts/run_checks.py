#!/usr/bin/env python3
"""Run the source/resource validator and every standalone regression test."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = [[sys.executable, "scripts/validate_project.py"]]
# Discover suites instead of maintaining a second hard-coded list. Any newly added
# regression test is therefore included in local checks and CI automatically.
TEST_SCRIPTS = sorted((ROOT / "scripts").glob("test_*.py"))
COMMANDS.extend([[sys.executable, str(path.relative_to(ROOT))] for path in TEST_SCRIPTS])
if not TEST_SCRIPTS:
    print("No regression test scripts found under scripts/test_*.py", file=sys.stderr)
    raise SystemExit(2)

for command in COMMANDS:
    print("\n$ " + " ".join(command), flush=True)
    completed = subprocess.run(command, cwd=ROOT, check=False)
    if completed.returncode:
        print(f"FAILED (exit {completed.returncode}): {' '.join(command)}", file=sys.stderr)
        raise SystemExit(completed.returncode)

print("\nAll source/resource checks and regression tests passed.")
