package net.fybertech.modelcitizens.client;

import net.fybertech.modelcitizens.menu.CitizenMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class CitizenScreen extends AbstractContainerScreen<CitizenMenu> {
    public CitizenScreen(CitizenMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 248;
        this.imageHeight = 238;
        this.titleLabelX = 8;
        this.titleLabelY = 6;
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        // The player-inventory heading is drawn in renderBg at y=137. Suppress
        // AbstractContainerScreen's default inventory label, which would overlap
        // the first row of slots in this taller custom layout.
        graphics.drawString(font, title, titleLabelX, titleLabelY, 0xFFFFFF, false);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFF252525);
        graphics.fill(leftPos + 4, topPos + 4, leftPos + imageWidth - 4, topPos + imageHeight - 4, 0xFF3A3A3A);
        graphics.fill(leftPos + 6, topPos + 24, leftPos + imageWidth - 6, topPos + 124, 0xFF202020);
        // Slot outlines are drawn manually because this screen has no texture atlas.
        for (int i = 0; i < 4; i++) graphics.fill(leftPos + 7, topPos + 27 + i * 18, leftPos + 25, topPos + 45 + i * 18, 0xFF777777);
        // Dedicated held-item slot (handler slot 40) sits below the armor column.
        graphics.fill(leftPos + 7, topPos + 107, leftPos + 25, topPos + 125, 0xFF777777);
        for (int row = 0; row < 4; row++) for (int col = 0; col < 9; col++)
            graphics.fill(leftPos + 79 + col * 18, topPos + 27 + row * 18, leftPos + 97 + col * 18, topPos + 45 + row * 18, 0xFF777777);
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++)
            graphics.fill(leftPos + 7 + col * 18, topPos + 153 + row * 18, leftPos + 25 + col * 18, topPos + 171 + row * 18, 0xFF777777);
        for (int col = 0; col < 9; col++)
            graphics.fill(leftPos + 7 + col * 18, topPos + 211, leftPos + 25 + col * 18, topPos + 229, 0xFF777777);
        graphics.drawString(font, Component.translatable("screen.modelcitizens.inventory.armor"), leftPos + 7, topPos + 14, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("screen.modelcitizens.inventory.citizen"), leftPos + 80, topPos + 14, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("screen.modelcitizens.inventory.player"), leftPos + 7, topPos + 137, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("screen.modelcitizens.inventory.held"), leftPos + 29, topPos + 112, 0xFFFFFF, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
