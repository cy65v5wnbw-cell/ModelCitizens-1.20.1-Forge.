#!/usr/bin/env python3
"""Regression checks for editor controls on small Minecraft GUI resolutions."""
from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCREEN = (ROOT / "src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java").read_text(encoding="utf-8")


class EditorLayoutTests(unittest.TestCase):
    def test_compact_layout_is_selected_for_small_windows(self) -> None:
        self.assertIn("compactLayout = width < 640 || height < 360", SCREEN)
        self.assertIn("if (compactLayout) {", SCREEN)
        self.assertIn("if (!compactLayout)", SCREEN)
        self.assertIn("Long explanatory hints assume the desktop layout width", SCREEN)

    def test_all_nine_controls_are_present_in_compact_layout(self) -> None:
        for key in (
            "screen.modelcitizens.editor.scale",
            "screen.modelcitizens.editor.body_yaw",
            "screen.modelcitizens.editor.head_yaw",
            "screen.modelcitizens.editor.head_pitch",
            "screen.modelcitizens.editor.left_arm",
            "screen.modelcitizens.editor.right_arm",
            "screen.modelcitizens.editor.left_leg",
            "screen.modelcitizens.editor.right_leg",
            "screen.modelcitizens.editor.rotation",
        ):
            self.assertIn(key, SCREEN)
        self.assertIn("addCompactSlider(secondColumn, 86, columnWidth, compactSliderHeight", SCREEN)
        self.assertIn("compactSliderPitch * 3", SCREEN)

    def test_columns_are_sized_to_the_logical_screen_width(self) -> None:
        self.assertIn("Math.max(70, Math.min(145, (width - columnGap - 8) / 2))", SCREEN)
        self.assertIn("int layoutWidth = columnWidth * 2 + columnGap", SCREEN)
        self.assertIn("int secondColumn = left + columnWidth + columnGap", SCREEN)
        # Exercise the exact layout arithmetic for narrow GUI widths.
        for width in (150, 158, 160, 170, 180, 190, 200, 210, 220, 240, 280, 300, 320, 400, 639):
            column_gap = 10
            column_width = max(70, min(145, (width - column_gap - 8) // 2))
            layout_width = column_width * 2 + column_gap
            left = max(0, (width - layout_width) // 2)
            second = left + column_width + 10
            self.assertGreaterEqual(left, 0, f"negative left edge at width {width}")
            self.assertLessEqual(left + layout_width, width, f"layout clipped at width {width}")
            self.assertLessEqual(second + column_width, width, f"right column clipped at width {width}")

    def test_compact_controls_and_action_row_fit_short_heights(self) -> None:
        self.assertIn("int actionY = compactLayout ? Math.min(280, Math.max(150, height - 24)) : 280", SCREEN)
        self.assertIn("int compactSliderHeight", SCREEN)
        self.assertIn("int compactSliderPitch = compactSliderHeight + 3", SCREEN)
        for height in (180, 190, 200, 220, 240, 280, 320, 359):
            action_y = min(280, max(150, height - 24))
            slider_height = max(10, min(20, (action_y - 86 - 12) // 5))
            pitch = slider_height + 3
            last_slider_bottom = 86 + pitch * 4 + slider_height
            self.assertLessEqual(last_slider_bottom, action_y, f"last slider overlaps actions at height {height}")
            self.assertLessEqual(action_y + 20, height, f"action row clipped at height {height}")

    def test_preview_is_hidden_when_it_would_be_offscreen(self) -> None:
        self.assertIn("if (!compactLayout) {", SCREEN)
        self.assertIn("int previewX = width / 2 + 220", SCREEN)


if __name__ == "__main__":
    unittest.main(verbosity=2)
