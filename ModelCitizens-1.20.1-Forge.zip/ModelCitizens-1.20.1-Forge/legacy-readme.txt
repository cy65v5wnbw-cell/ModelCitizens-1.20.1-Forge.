Model Citizens - v1.0.1 for Minecraft 1.7.10 - By FyberOptic
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Model Citizens allows you to place character models into the world
which can be posed, wear armor, hold items, and have a complete
inventory that players can loot.

Models can be spawned by using a Model Placer item, craftable using 
the recipe:

    " C "
    "LFL"
    "S S"
 
C = Raw chicken, L = leather, F = feather, and S = stick

Crafting of the Model Placer can be disabled in the config if 
desired.  Using a newly crafted Model Placer produces a Steve model 
by default, facing your orientation.

Right-clicking a model provides you access to its inventory.  At the 
top left are standard armor slots, which will render on the model.
The top right area will display the model's name.  Below is a 
standard player inventory arrangement, with the bottom-left slot 
having a hand icon.  Any object you place in this slot will render 
in the model's hand.  There's a config option available if you wish
to disable the player's ability to place items back into the 
inventory in survival mode.

When the invulnerability config option is disabled, models are weak 
against shovels, but are still invulnerable to explosion damage.  
This prevents accidental removal of important models (and their 
inventories) from your maps.  When broken, the model drops its full 
inventory and optionally a Model Placer item (enabled by default).  
The item will retain its information and can be placed again in the 
world, with only its orientation changing when placed.

When in creative mode, using middle-click to pick the block will 
similarly duplicate a model, as well as its entire inventory.  This
allows you to quickly place many similar copies in the world.

To pose and customize a model, shift-right click its base with an 
empty hand to access its configuration GUI (can be disabled for 
players in survival mode via the config).  There are several pages 
of settings.  The initial page allows you to specify the model type 
(either standard or skeleton), and to enter a username to use for 
the texture.  The other pages allow you to set the model's 
orientation.

Using the mouse wheel in the configuration GUI will either flip
through the pages or finely tune a slider control depending on what 
you're hovering over.  Holding shift while doing this will adjust 
a slider even more precisely.

Right-clicking in the configuration GUI will toggle the controls up
and down, allowing you to move it out of the way while posing it.  
Both the position and the page will be remembered if you exit the 
GUI, making it easy to pick up where you left off if you have to 
move your character for a better view while posing.

If you wish to use a different display name than the texture name,
or want to use a default Steve or skeleton texture along with a 
custom name, then the exclamation mark can be used as a separator.  
Texture name goes first, then display name.  Leave the texture name 
blank to use the default Steve or skeleton ones.

Model textures are searched for locally first, from within the 
config/modelcitizens folder.  If not found there it will pull the 
standard model for that player from Mojang's servers.  Your custom 
textures should be in PNG format, and the filenames all lowercase.



-- Changelog --

v1.0.1 - Sunday June 14th, 2015
 - Added config option to allow access to configuration GUI from survival mode (default true)
 - Added config option and recipe to allow crafting of Model Placer (default true)
 - Added config option to allow players to place items into model's inventory in survival (default true)
 - Changed dropModel to true by default

v1.0 - Friday May 29th, 2015
 - Added ability to scale models
 - Mouse wheel now scrolls through model configuration GUI pages
 - Mouse wheel finely tunes sliders, even more precise if shift is held

v0.9.2 - Monday May 25th, 2015
 - Increased render bounding box to pass frustum check

v0.9.1 - Sunday May 24th, 2015
 - Fixed crash in model configuration GUI 

v0.9 - Sunday May 24th, 2015
 - Added config options for invulnerability and model item drops
 - Changed name field to allow ! to separate texture and displayed name
 - Got rid of lava block breaking texture
 - Fixed name not being saved if GUI closed too quickly after changing 

v0.8.1 - Sunday May 24th, 2015
 - Fixed bug introduced in 0.8 preventing skeleton model from being posed 
 - Changed custom texture location to config folder

v0.8 - Sunday May 24th, 2015
 - Fixed face culling for skeleton
 - Fixed server-side crash on startup
 - Models can be broken (vulnerable to shovel), still explosion-proof
 - Models drop their items and a copy of themselves in survival mode
 - Middle-click block select in creative mode duplicates model and inventory
 - Added ability to add custom model textures into JAR

v0.7 - Saturday May 23rd, 2015
 - Initial release!
 



