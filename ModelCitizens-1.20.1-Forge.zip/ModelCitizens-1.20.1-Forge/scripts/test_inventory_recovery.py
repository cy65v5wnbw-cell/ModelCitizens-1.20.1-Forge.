#!/usr/bin/env python3
"""Focused regression tests for the intended fixed-size inventory NBT recovery rules.

This is a dependency-free behavioral model of the recovery policy, not an execution
of Forge's ItemStackHandler. The Java source is separately checked by validate_project.py.
"""
from __future__ import annotations

import unittest

MAIN_SIZE = 36
HAND_SLOT = 40
TOTAL_SIZE = 41


def recover_slots(entries: list[tuple[int, str]]) -> dict[int, str]:
    """Model the source's policy: accept first valid slot, relocate collisions safely."""
    occupied = [False] * TOTAL_SIZE
    recovered: dict[int, str] = {}
    duplicates: list[str] = []
    for slot, stack in entries:
        if not 0 <= slot < TOTAL_SIZE:
            continue
        if occupied[slot]:
            duplicates.append(stack)
            continue
        occupied[slot] = True
        recovered[slot] = stack

    for stack in duplicates:
        free_slot = next((i for i in range(MAIN_SIZE) if not occupied[i]), -1)
        if free_slot < 0 and not occupied[HAND_SLOT]:
            free_slot = HAND_SLOT
        if free_slot < 0:
            continue
        occupied[free_slot] = True
        recovered[free_slot] = stack
    return recovered


class InventoryRecoveryTests(unittest.TestCase):
    def test_duplicate_slot_is_relocated_not_overwritten(self) -> None:
        result = recover_slots([(0, "diamond"), (0, "apple")])
        self.assertEqual(result[0], "diamond")
        self.assertEqual(result[1], "apple")

    def test_recovery_does_not_overwrite_other_valid_slots(self) -> None:
        result = recover_slots([(0, "diamond"), (1, "iron"), (0, "apple")])
        self.assertEqual(result, {0: "diamond", 1: "iron", 2: "apple"})

    def test_out_of_range_slots_are_ignored(self) -> None:
        result = recover_slots([(-1, "negative"), (41, "too-high"), (40, "hand")])
        self.assertEqual(result, {40: "hand"})

    def test_duplicate_uses_hand_when_main_inventory_is_full(self) -> None:
        entries = [(slot, f"stack-{slot}") for slot in range(MAIN_SIZE)]
        entries.append((0, "recovered"))
        result = recover_slots(entries)
        self.assertEqual(result[0], "stack-0")
        self.assertEqual(result[40], "recovered")
        self.assertEqual(len(result), MAIN_SIZE + 1)  # 36 main slots plus the hand slot

    def test_excess_duplicates_do_not_replace_valid_items(self) -> None:
        entries = [(slot, f"stack-{slot}") for slot in range(TOTAL_SIZE)]
        entries.extend([(0, "overflow-a"), (0, "overflow-b")])
        result = recover_slots(entries)
        self.assertEqual(len(result), TOTAL_SIZE)
        self.assertEqual(result[0], "stack-0")
        self.assertEqual(result[40], "stack-40")


if __name__ == "__main__":
    unittest.main(verbosity=2)
