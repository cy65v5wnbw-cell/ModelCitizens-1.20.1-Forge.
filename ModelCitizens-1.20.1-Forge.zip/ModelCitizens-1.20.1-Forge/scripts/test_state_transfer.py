#!/usr/bin/env python3
"""Source-level regression checks for citizen state transfer and item drops.

These checks protect data-transfer boundaries; they are not runtime Forge tests.
"""
from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


class StateTransferTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.block_entity = read("src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java")
        cls.block = read("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java")
        cls.placer = read("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java")

    def test_placer_has_a_separate_visual_save_method(self) -> None:
        self.assertIn("public CompoundTag saveVisualData()", self.block_entity)
        self.assertIn("writeVisualData(tag)", self.block_entity)
        self.assertIn('tag.put("Inventory", inventory.serializeNBT())', self.block_entity)

    def test_placer_restore_does_not_call_full_block_entity_load(self) -> None:
        start = self.block_entity.index("public void initializeForPlacement(CompoundTag visualData, float placementYaw)")
        end = self.block_entity.index("private void writeVisualData", start)
        method = self.block_entity[start:end]
        self.assertIn("readVisualData(visualData)", method)
        self.assertIn("applyPose(placementYaw, initialScale, initialPose)", method)
        self.assertNotIn("load(visualData)", method)
        self.assertNotIn("deserializeNBT", method)
        self.assertNotIn("syncToClient()", method)

    def test_placer_item_reads_only_the_visual_tag(self) -> None:
        self.assertIn('contains("ModelCitizensData", net.minecraft.nbt.Tag.TAG_COMPOUND)', self.placer)
        self.assertIn('? itemTag.getCompound("ModelCitizensData") : null;', self.placer)
        self.assertIn("citizen.initializeForPlacement(visualData, placementYaw)", self.placer)
        self.assertNotIn("getCompound(\"Inventory\")", self.placer)
        self.assertNotIn("citizen.load(", self.placer)

    def test_placer_faces_the_player_while_preserving_saved_pose_and_scale(self) -> None:
        self.assertIn("float placementYaw = context.getPlayer() == null ? 0.0F : context.getPlayer().getYRot()", self.placer)
        self.assertIn("citizen.initializeForPlacement(visualData, placementYaw)", self.placer)
        self.assertIn("float initialScale = visualData == null ? 1.0F : scale", self.block_entity)
        self.assertIn("float[] initialPose = visualData == null ? new float[POSE_SIZE] : pose.clone()", self.block_entity)

    def test_creative_pick_block_deliberately_keeps_full_state(self) -> None:
        self.assertIn('put("BlockEntityTag", citizen.saveWithoutMetadata())', self.block)
        self.assertIn("new ItemStack(ModItems.CITIZEN.get())", self.block)

    def test_breaking_citizen_drains_inventory_once(self) -> None:
        self.assertIn("citizen.drainInventoryForRemoval()", self.block)
        self.assertIn("GameRules.RULE_DOBLOCKDROPS", self.block)
        self.assertIn("if (dropsEnabled) popResource(level, pos, stack)", self.block)

    def test_placer_drop_is_configurable_and_visual_only(self) -> None:
        self.assertIn("DROP_MODEL.get()", self.block)
        self.assertIn("citizen.saveVisualData()", self.block)
        self.assertIn('put("ModelCitizensData", visualData)', self.block)
        self.assertNotIn('put("Inventory", visualData)', self.block)

    def test_inventory_is_fixed_size_and_missing_inventory_is_cleared(self) -> None:
        self.assertIn("new ItemStackHandler(TOTAL_SIZE)", self.block_entity)
        self.assertIn('tag.contains("Inventory", Tag.TAG_COMPOUND)', self.block_entity)
        self.assertIn("inventory.setStackInSlot(slot, ItemStack.EMPTY)", self.block_entity)

    def test_client_sync_is_suppressed_while_loading_and_draining(self) -> None:
        self.assertIn("suppressInventorySync = true", self.block_entity)
        self.assertIn("if (!suppressInventorySync && level != null && !level.isClientSide)", self.block_entity)


if __name__ == "__main__":
    unittest.main(verbosity=2)
