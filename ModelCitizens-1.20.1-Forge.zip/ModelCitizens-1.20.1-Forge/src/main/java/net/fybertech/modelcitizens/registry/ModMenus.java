package net.fybertech.modelcitizens.registry;

import net.fybertech.modelcitizens.ModelCitizens;
import net.fybertech.modelcitizens.menu.CitizenMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ModelCitizens.MODID);
    public static final RegistryObject<MenuType<CitizenMenu>> CITIZEN = MENUS.register("citizen", () ->
        IForgeMenuType.create((id, inv, data) -> {
            BlockPos pos = data.readBlockPos();
            BlockEntity be = inv.player.level().getBlockEntity(pos);
            return new CitizenMenu(id, inv, be instanceof net.fybertech.modelcitizens.world.CitizenBlockEntity c ? c : null);
        }));
    private ModMenus() {}
}
