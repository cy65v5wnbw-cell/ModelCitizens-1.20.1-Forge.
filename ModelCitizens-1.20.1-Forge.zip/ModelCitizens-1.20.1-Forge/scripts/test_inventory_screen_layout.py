#!/usr/bin/env python3
"""Guard against GUI slot coordinates drifting away from their drawn outlines."""
from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MENU = (ROOT / "src/main/java/net/fybertech/modelcitizens/menu/CitizenMenu.java").read_text(encoding="utf-8")
SCREEN = (ROOT / "src/main/java/net/fybertech/modelcitizens/client/CitizenScreen.java").read_text(encoding="utf-8")


class InventoryScreenLayoutTests(unittest.TestCase):
    def test_menu_slot_rows_match_background_outlines(self) -> None:
        for expression in (
            r"36 \+ i, 8, 28 \+ i \* 18",
            r"row \* 9 \+ col, 80 \+ col \* 18, 28 \+ row \* 18",
            r"handler, 40, 8, 108",
            r"col \+ row \* 9 \+ 9, 8 \+ col \* 18, 154 \+ row \* 18",
            r"playerInventory, col, 8 \+ col \* 18, 212",
        ):
            self.assertRegex(MENU, expression)
        for expression in (
            r"topPos \+ 27 \+ i \* 18",
            r"topPos \+ 27 \+ row \* 18",
            r"topPos \+ 107",
            r"topPos \+ 153 \+ row \* 18",
            r"topPos \+ 211",
        ):
            self.assertRegex(SCREEN, expression)

    def test_header_labels_are_inside_screen_and_above_slots(self) -> None:
        self.assertIn("this.imageHeight = 238", SCREEN)
        self.assertIn("leftPos + 7, topPos + 14", SCREEN)
        self.assertIn("leftPos + 80, topPos + 14", SCREEN)
        self.assertIn("leftPos + 7, topPos + 137", SCREEN)
        self.assertNotIn("topPos - 5", SCREEN)

    def test_default_inventory_heading_is_suppressed(self) -> None:
        self.assertIn("protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY)", SCREEN)
        self.assertIn("graphics.drawString(font, title, titleLabelX, titleLabelY, 0xFFFFFF, false)", SCREEN)
        self.assertNotIn("this.inventoryLabelY = 148", SCREEN)
        self.assertIn("topPos + 137", SCREEN)

    def test_inventory_rows_fit_inside_screen_bounds(self) -> None:
        self.assertIn("topPos + imageHeight", SCREEN)
        self.assertIn("topPos + 229", SCREEN)
        self.assertIn("this.imageHeight = 238", SCREEN)


if __name__ == "__main__":
    unittest.main(verbosity=2)
