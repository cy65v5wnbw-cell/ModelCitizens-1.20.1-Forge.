package net.fybertech.modelcitizens.menu;

import net.fybertech.modelcitizens.registry.ModMenus;
import net.fybertech.modelcitizens.world.CitizenBlockEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorItem;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.fybertech.modelcitizens.ModConfigSpecHolder;

public class CitizenMenu extends AbstractContainerMenu {
    private final CitizenBlockEntity citizen;
    public CitizenMenu(int id, Inventory playerInventory, CitizenBlockEntity citizen) {
        super(ModMenus.CITIZEN.get(), id);
        this.citizen = citizen;
        boolean canInsert = playerInventory.player.isCreative() || ModConfigSpecHolder.SURVIVAL_CAN_INSERT.get();
        // Always create the same 41 citizen slots on client and server. If the block
        // entity is missing on one side, a dummy handler keeps menu slot indices aligned;
        // stillValid() closes the invalid menu immediately.
        ItemStackHandler handler = citizen == null ? new ItemStackHandler(CitizenBlockEntity.TOTAL_SIZE) : citizen.inventory();
        for (int i = 0; i < 4; i++) addSlot(new CitizenSlot(handler, 36 + i, 8, 28 + i * 18, canInsert));
        for (int row = 0; row < 4; row++) for (int col = 0; col < 9; col++)
            addSlot(new CitizenSlot(handler, row * 9 + col, 80 + col * 18, 28 + row * 18, canInsert));
        addSlot(new CitizenSlot(handler, 40, 8, 108, canInsert));
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++)
            addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 154 + row * 18));
        for (int col = 0; col < 9; col++) addSlot(new Slot(playerInventory, col, 8 + col * 18, 212));
    }
    private static final class CitizenSlot extends SlotItemHandler {
        private final boolean canInsert;
        private final int handlerSlot;
        private CitizenSlot(ItemStackHandler handler, int handlerSlot, int x, int y, boolean canInsert) {
            super(handler, handlerSlot, x, y);
            this.handlerSlot = handlerSlot;
            this.canInsert = canInsert;
        }
        @Override public boolean mayPlace(ItemStack stack) {
            if (!canInsert) return false;
            // Validate by the backing handler slot, not Slot.index: the latter is
            // assigned by AbstractContainerMenu and differs from handler indices.
            if (handlerSlot >= 36 && handlerSlot <= 39) {
                if (!(stack.getItem() instanceof ArmorItem armor)) return false;
                net.minecraft.world.entity.EquipmentSlot expected = switch (handlerSlot) {
                    case 36 -> net.minecraft.world.entity.EquipmentSlot.HEAD;
                    case 37 -> net.minecraft.world.entity.EquipmentSlot.CHEST;
                    case 38 -> net.minecraft.world.entity.EquipmentSlot.LEGS;
                    case 39 -> net.minecraft.world.entity.EquipmentSlot.FEET;
                    default -> throw new IllegalStateException("Unexpected armor slot");
                };
                return armor.getSlot() == expected;
            }
            return true;
        }
    }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        if (index < 0 || index >= slots.size()) return ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack source = slot.getItem();
        ItemStack copy = source.copy();
        int citizenSlots = citizen == null ? 0 : 41;
        if (index < citizenSlots) {
            if (!moveItemStackTo(source, citizenSlots, slots.size(), true)) return ItemStack.EMPTY;
        } else if (!moveItemStackTo(source, 0, citizenSlots, false)) return ItemStack.EMPTY;
        if (source.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        return copy;
    }
    /** True only when this open menu belongs to the requested citizen block. */
    public boolean controls(net.minecraft.core.BlockPos pos) {
        return citizen != null && !citizen.isRemoved() && citizen.getBlockPos().equals(pos);
    }

    @Override public boolean stillValid(Player player) {
        if (citizen == null || citizen.isRemoved() || !player.mayBuild()) return false;
        if (player.distanceToSqr(citizen.getBlockPos().getX() + 0.5,
                citizen.getBlockPos().getY() + 0.5,
                citizen.getBlockPos().getZ() + 0.5) >= 64.0D) return false;
        return player.level().getBlockEntity(citizen.getBlockPos()) == citizen;
    }
}
