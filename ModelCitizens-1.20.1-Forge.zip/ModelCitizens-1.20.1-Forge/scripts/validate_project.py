#!/usr/bin/env python3
"""Static smoke checks for Model Citizens; not a substitute for ForgeGradle compilation."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOT = ROOT / "src/main/java"
RESOURCE_ROOT = ROOT / "src/main/resources"
JAVA_FILES = sorted(JAVA_ROOT.rglob("*.java"))
JSON_FILES = sorted(RESOURCE_ROOT.rglob("*.json"))
errors: list[str] = []
sources: dict[str, str] = {}

REQUIRED_FILES = [
    "build.gradle",
    "settings.gradle",
    "gradle.properties",
    "src/main/resources/META-INF/mods.toml",
    ".github/workflows/build.yml",
    "scripts/test_editor_security.py",
    "scripts/test_state_transfer.py",
    "scripts/test_state_sync_policy.py",
    "scripts/test_text_sanitizer.py",
    "scripts/test_texture_path_policy.py",
    "scripts/test_inventory_screen_layout.py",
    "scripts/run_checks.py",
    "scripts/build_mod.sh",
    "scripts/build_mod.ps1",
    "scripts/build_mod_docker.sh",
    "scripts/test_build_runner.py",
    "README.md",
]
for relative in REQUIRED_FILES:
    if not (ROOT / relative).is_file():
        errors.append(f"Missing required project file: {relative}")

# Strip comments and Java string/character literals before delimiter checks, so
# braces in documentation and resource strings do not cause false positives.
TOKEN_RE = re.compile(
    r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/'
)
PAIRS = {"}": "{", ")": "(", "]": "["}

for path in JAVA_FILES:
    rel = path.relative_to(ROOT).as_posix()
    text = path.read_text(encoding="utf-8")
    sources[rel] = text
    stripped = TOKEN_RE.sub(lambda match: "\n" * match.group(0).count("\n"), text)
    stack: list[tuple[str, int]] = []
    for offset, char in enumerate(stripped):
        if char in "{([":
            stack.append((char, offset))
        elif char in "})]":
            if not stack or stack[-1][0] != PAIRS[char]:
                line = stripped.count("\n", 0, offset) + 1
                errors.append(f"{rel}:{line}: mismatched delimiter {char}")
                break
            stack.pop()
    else:
        if stack:
            char, offset = stack[-1]
            line = stripped.count("\n", 0, offset) + 1
            errors.append(f"{rel}:{line}: unclosed delimiter {char}")

    packages = re.findall(r"^\s*package\s+([\w.]+)\s*;", stripped, re.MULTILINE)
    if len(packages) != 1:
        errors.append(f"{rel}: expected exactly one package declaration, found {len(packages)}")
    imports = re.findall(r"^\s*import\s+(?!static\b)([\w.]+)\s*;", stripped, re.MULTILINE)
    if len(imports) != len(set(imports)):
        errors.append(f"{rel}: duplicate import declaration")

json_data: dict[str, object] = {}
for path in JSON_FILES:
    try:
        json_data[path.relative_to(RESOURCE_ROOT).as_posix()] = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{path.relative_to(ROOT).as_posix()}: invalid JSON: {exc}")

# Validate the resource graph as well as JSON syntax. Valid JSON can still refer
# to missing models or omit the translation keys for registered items.
def model_resource_path(model_id: str) -> str | None:
    if ":" in model_id:
        namespace, path = model_id.split(":", 1)
    else:
        namespace, path = "minecraft", model_id
    if namespace == "minecraft":
        return None  # Vanilla resources are supplied by the game.
    return f"assets/{namespace}/models/{path}.json"

blockstate = json_data.get("assets/modelcitizens/blockstates/citizen.json")
if isinstance(blockstate, dict):
    variants = blockstate.get("variants", {})
    if isinstance(variants, dict):
        for variant in variants.values():
            entries = variant if isinstance(variant, list) else [variant]
            for entry in entries:
                if not isinstance(entry, dict) or not isinstance(entry.get("model"), str):
                    errors.append("citizen blockstate contains a malformed model variant")
                    continue
                model_path = model_resource_path(entry["model"])
                if model_path and not (RESOURCE_ROOT / model_path).is_file():
                    errors.append(f"citizen blockstate references missing model: {entry['model']}")

for resource_name, resource in json_data.items():
    if not resource_name.startswith("assets/") or "/models/" not in resource_name or not isinstance(resource, dict):
        continue
    parent = resource.get("parent")
    if isinstance(parent, str):
        parent_path = model_resource_path(parent)
        if parent_path and not (RESOURCE_ROOT / parent_path).is_file():
            errors.append(f"{resource_name} references missing parent model: {parent}")

# Keep the editor's visible text fully localizable and ensure every key used by
# the UI exists in both shipped language files.
english = json_data.get("assets/modelcitizens/lang/en_us.json")
russian = json_data.get("assets/modelcitizens/lang/ru_ru.json")
if not isinstance(english, dict):
    errors.append("Missing or malformed English language file")
if not isinstance(russian, dict):
    errors.append("Missing or malformed Russian language file")
if isinstance(english, dict) and isinstance(russian, dict):
    for key in sorted(set(english) - set(russian)):
        errors.append(f"Russian language file is missing key: {key}")
    for key in sorted(set(russian) - set(english)):
        errors.append(f"English language file is missing key: {key}")
    for rel, source in sources.items():
        for key in re.findall(r'Component\.translatable\(\s*"([^"]+)"', source):
            # gui.cancel is supplied by Minecraft itself, not by this mod.
            if not (key.startswith("screen.modelcitizens.") or key.startswith("gui.modelcitizens.")):
                continue
            if key not in english:
                errors.append(f"{rel}: translation key is missing from en_us.json: {key}")
            if key not in russian:
                errors.append(f"{rel}: translation key is missing from ru_ru.json: {key}")

for relative, model_key in (("assets/modelcitizens/models/item/citizen.json", "item.modelcitizens.citizen"),
                             ("assets/modelcitizens/models/item/placer.json", "item.modelcitizens.placer")):
    model = json_data.get(relative)
    if not isinstance(model, dict):
        errors.append(f"Missing or malformed item model: {relative}")
    lang = json_data.get("assets/modelcitizens/lang/en_us.json")
    if not isinstance(lang, dict) or model_key not in lang:
        errors.append(f"Missing English translation key: {model_key}")

recipe = json_data.get("data/modelcitizens/recipes/placer.json")
if isinstance(recipe, dict):
    result = recipe.get("result")
    if not isinstance(result, dict) or result.get("item") != "modelcitizens:placer":
        errors.append("placer recipe must produce modelcitizens:placer")
    pattern = recipe.get("pattern", [])
    key = recipe.get("key", {})
    if isinstance(pattern, list) and isinstance(key, dict):
        used_symbols = {char for row in pattern if isinstance(row, str) for char in row if char != " "}
        if used_symbols != set(key):
            errors.append("placer recipe pattern symbols do not match its key entries")

packet = sources.get("src/main/java/net/fybertech/modelcitizens/network/SetCitizenPosePacket.java", "")
be = sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java", "")
menu = sources.get("src/main/java/net/fybertech/modelcitizens/menu/CitizenMenu.java", "")
renderer = sources.get("src/main/java/net/fybertech/modelcitizens/client/CitizenRenderer.java", "")
editor = sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
build = (ROOT / "build.gradle").read_text(encoding="utf-8") if (ROOT / "build.gradle").exists() else ""
mods = (ROOT / "src/main/resources/META-INF/mods.toml").read_text(encoding="utf-8") if (ROOT / "src/main/resources/META-INF/mods.toml").exists() else ""

checks = [
    ("glob(\"test_*.py\")" in (ROOT / "scripts/run_checks.py").read_text(encoding="utf-8")
     and "scripts/validate_project.py" in (ROOT / "scripts/run_checks.py").read_text(encoding="utf-8"),
     "one documented command must run the validator and automatically discover all regression suites"),
    ("gradle --no-daemon clean build" in (ROOT / "README.md").read_text(encoding="utf-8") and "not proof" in (ROOT / "README.md").read_text(encoding="utf-8"),
     "README must document the Forge build and distinguish static checks from a real compile"),
    ("this.pose = new float[CitizenBlockEntity.POSE_SIZE]" in packet and "if (pose != null)" in packet,
     "locally-created packets must normalize null or wrong-sized pose arrays to the fixed protocol size"),
    ("this.texture = boundedUtf(texture, 64)" in packet and "this.name = boundedUtf(name, 64)" in packet
     and "private static String boundedUtf(String value, int maxLength)" in packet
     and "Character.isHighSurrogate" in packet,
     "packet strings must be bounded before writeUtf encoding without splitting surrogate pairs"),
    ("private static String boundedText(String value, int maxLength)" in be
     and "CitizenTextSanitizer.sanitizeSingleLine(value, maxLength)" in be
     and "cleaned.codePointAt(offset)" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java", "")
     and "safe.appendCodePoint(codePoint)" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java", "")
     and "Character.isISOControl(codePoint)" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java", "")
     and "isBidiControl(codePoint)" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java", ""),
     "persisted/display text must use the tested code-point sanitizer and reject control/bidi override characters"),
    ("CitizenBlockEntity.POSE_SIZE" in packet and "if (n != CitizenBlockEntity.POSE_SIZE)" in packet,
     "pose packet must use the shared fixed pose size when decoding"),
    ("POSE_SIZE = 7" in be and "new float[POSE_SIZE]" in be and "Pose6" in be,
     "block entity must use the shared seven-value pose size and migrate legacy poses"),
    ("new float[CitizenBlockEntity.POSE_SIZE]" in editor and "pose[6]" in editor,
     "editor must expose the seventh pose value using the shared size"),
    ("Float.isFinite(value)" in packet, "network handler must reject non-finite pose values"),
    ("isInWorldBounds(p.pos)" in packet and "getBlockState(p.pos).is(net.fybertech.modelcitizens.registry.ModBlocks.CITIZEN.get())" in packet,
     "editor packet must reject out-of-world positions and positions that are not the registered citizen block"),
    ("EditorGrantManager.permits(player, player.level(), p.pos, citizen)" in packet
     and "EditorGrantManager.issue(player, level, citizen)" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and "private static final long GRANT_TICKS = 200L" in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", "")
     and "private record Grant(long position, String dimension, UUID blockEntityToken, long expiresAt)" in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", "")
     and "grant.blockEntityToken().equals(citizen.editorToken())" in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", "")
     and "private final UUID editorToken = UUID.randomUUID()" in be,
     "pose editor must use a short-lived server-memory grant tied to the interacted citizen and dimension"),
    ("level.getGameTime() >= grant.expiresAt()" in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", ""),
     "editor grants must expire at the exact configured deadline rather than one tick late"),
    ("private final UUID editorToken = UUID.randomUUID()" in be
     and "grant.blockEntityToken().equals(citizen.editorToken())" in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", ""),
     "a stale editor grant must not authorize a replacement block entity at the same coordinates"),
    ("EditorGrantManager.clear(event.getEntity())" in sources.get("src/main/java/net/fybertech/modelcitizens/ModelCitizens.java", "")
     and "onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event)" in sources.get("src/main/java/net/fybertech/modelcitizens/ModelCitizens.java", "")
     and "onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event)" in sources.get("src/main/java/net/fybertech/modelcitizens/ModelCitizens.java", "")
     and "onPlayerDeath(PlayerEvent.PlayerRespawnEvent event)" in sources.get("src/main/java/net/fybertech/modelcitizens/ModelCitizens.java", "")
     and "onServerStopping(ServerStoppingEvent event)" in sources.get("src/main/java/net/fybertech/modelcitizens/ModelCitizens.java", "")
     and "public static void clearAll()" in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", "")
     and 'getPersistentData()' not in sources.get("src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java", ""),
     "editor grants must be ephemeral and cleared on logout, dimension change, respawn, and server shutdown"),
    ("if (slot >= MAIN_SIZE) syncToClient();" in be
     and "36 main inventory slots are synchronized by the open menu" in be,
     "only renderer-visible equipment/hand changes should broadcast full block-entity NBT; main slots use menu sync"),
    (all(slot in menu for slot in ("EquipmentSlot.HEAD", "EquipmentSlot.CHEST", "EquipmentSlot.LEGS", "EquipmentSlot.FEET"))
     and "armor.getSlot()" in menu, "menu must validate all four armor slots using the Minecraft 1.20.1 API"),
    ("armor.getSlot()" in renderer and "armor.getEquipmentSlot()" not in renderer,
     "armor renderer must use Minecraft 1.20.1 ArmorItem#getSlot"),
    ("ItemTransforms.TransformType.THIRD_PERSON_RIGHT_HAND" in renderer and "ItemDisplayContext" not in renderer,
     "held-item rendering must use the Minecraft 1.20.1 ItemTransforms.TransformType API"),
    ("private static boolean isTextureResource(ResourceLocation location)" in renderer
     and "CitizenTexturePathPolicy.isSafeTextureLocation(location.getNamespace(), location.getPath())" in renderer
     and "isTextureResource(parsed)" in renderer,
     "world renderer must use the shared safe PNG texture-path policy and require an existing resource"),
    ("private static boolean isTextureResource(ResourceLocation location)" in editor
     and "CitizenTexturePathPolicy.isSafeTextureLocation(location.getNamespace(), location.getPath())" in editor
     and "isTextureResource(parsed)" in editor,
     "editor preview must use the same shared texture-path restrictions as the world renderer"),
    ("path.indexOf('\\\\') >= 0" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", "")
     and '"..".equals(segment)' in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", "")
     and '".".equals(segment)' in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", "")
     and 'path.endsWith(".png")' in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", "")
     and "c >= 'a' && c <= 'z'" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", ""),
     "shared texture policy must reject traversal/dot segments, unsafe characters, backslashes, and non-PNG paths"),
    ("CitizenTexturePathPolicy.isSafeTextureId(texture)" in sources.get("src/main/java/net/fybertech/modelcitizens/network/SetCitizenPosePacket.java", "")
     and "private static String safeTextureId(String value)" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java", "")
     and "textureName = safeTextureId(tag.getString(\"TextureName\"))" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java", ""),
     "texture IDs must be validated on network input and when loading saved block-entity data"),
    ("public static boolean isSafeTextureLocation(String namespace, String path)" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", "")
     and "public static boolean isSafeTextureId(String value)" in sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java", ""),
     "texture policy must validate both resource namespace and path"),
    ("cameraPosition.distanceToSqr(citizenCenter) > 64.0D * 64.0D" in renderer
     and "Math.max(0.65D, 2.05D * be.scale())" in renderer,
     "name labels must be distance-culled and positioned relative to citizen scale"),
    ("model.hat.render(pose, vertex" in renderer, "helmet rendering must include the outer humanoid hat part"),
    (all(f"humanoid.{part}.yRot = humanoid.body.yRot" in renderer for part in ("leftArm", "rightArm", "leftLeg", "rightLeg"))
     and all(f"model.{part}.yRot = model.body.yRot" in editor for part in ("leftArm", "rightArm", "leftLeg", "rightLeg")),
     "body yaw must propagate to sibling limb model parts in both renderer and editor preview"),
    ("handModel.translateToHand(HumanoidArm.RIGHT, pose)" in renderer and "rightHandAnchor.translateAndRotate" not in renderer, "held item must use the full humanoid right-hand transform, including the torso hierarchy"),
    ("dyeableItem.getColor(armorStack)" in renderer and "dyeableItem.hasCustomColor(armorStack)" in renderer,
     "dyeable armor must use the 1.20.1 instance API and only tint explicitly dyed stacks"),
    ("DyeableLeatherItem.getColor(" not in renderer, "do not call the dyeable-item instance method as a static method"),
    ("!level.isInWorldBounds(pos) || !level.getWorldBorder().isWithinBounds(pos)" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "")
     and sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "").index("!level.isInWorldBounds(pos)") < sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "").index("getBlockState(pos)"),
     "custom placer must reject out-of-world and world-border destinations before reading the target block state"),
    ("level.playSound(null, pos, state.getSoundType().getPlaceSound(), SoundSource.BLOCKS" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "")
     and "level.gameEvent(context.getPlayer(), GameEvent.BLOCK_PLACE, pos);" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", ""),
     "successful custom placement must emit vanilla-style placement sound and block-place game event"),
    ("syncToClient();" in be, "block entity must synchronize changes to tracking clients"),
    ("public void applyEditorState(String texture, String display, int type," in be
     and "applyPose(yaw, scale, values);" in be
     and "citizen.applyEditorState(texture, name, p.modelType, p.yaw, p.scale, p.pose);" in packet
     and "citizen.setIdentity(texture, name, p.modelType);" not in packet,
     "one editor packet must commit identity and pose together with a single synchronization update"),
    ("private boolean suppressInventorySync;" in be and "if (!suppressInventorySync && level != null && !level.isClientSide)" in be
     and "suppressInventorySync = true;" in be and "finally {\n            suppressInventorySync = false;" in be,
     "NBT deserialization must suppress per-slot client updates while restoring the inventory"),
    ("public List<ItemStack> drainInventoryForRemoval()" in be and "citizen.drainInventoryForRemoval()" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and "if (dropsEnabled) popResource(level, pos, stack)" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", ""),
     "block removal must drain inventory without per-slot sync and respect doTileDrops"),
    ("@Override public boolean isItemValid(int slot, ItemStack stack)" in be and "armor.getSlot() == expected" in be,
     "inventory handler must reject armor inserted into the wrong equipment slot using getSlot"),
    ("@Override public int getSlotLimit(int slot)" in be and "slot >= 36 && slot <= 39 ? 1" in be,
     "each citizen armor slot must be limited to one item, including modded armor stacks"),
    ('item.contains("Slot", Tag.TAG_INT) ? item.getInt("Slot") : item.getByte("Slot")' in be
     and 'normalized.putByte("Slot", (byte) slot)' in be and 'normalizeSlotTag(item, slot)' in be,
     "NBT inventory slot indices must be read according to their stored type and normalized to the byte format expected by ItemStackHandler"),
    ("List<CompoundTag> duplicateSlots = new ArrayList<>();" in be
     and "if (occupied[slot])" in be and "normalizeSlotTag(duplicate, freeSlot)" in be,
     "duplicate NBT inventory slot entries should be relocated to free main slots instead of silently overwriting earlier stacks"),
    ("normalizeLoadedArmorSlots();" in be and "private void normalizeLoadedArmorSlots()" in be
     and "armor.getSlot() == expected" in be and "inventory.getStackInSlot(mainSlot).isEmpty()" in be,
     "malformed armor saved in the wrong equipment slot should move to an empty main slot without being deleted"),
    ("@Override public void deserializeNBT(CompoundTag nbt)" in be and "safe.putInt(\"Size\", TOTAL_SIZE)" in be
     and "slot >= 0 && slot < TOTAL_SIZE" in be and "safe.put(\"Items\", boundedItems)" in be,
     "inventory NBT must preserve the fixed 41-slot layout and ignore out-of-range saved slots"),
    ('tag.contains("Inventory", Tag.TAG_COMPOUND)' in be and "inventory.setStackInSlot(slot, ItemStack.EMPTY);" in be,
     "loading NBT without an Inventory compound must clear stale stacks instead of retaining previous state"),
    ("ArmorItem.Type" not in menu + be and "armor.getType()" not in menu + be,
     "do not use post-1.20.1 ArmorItem.Type/getType API"),
    ("GameRules.RULE_DOBLOCKDROPS" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and "citizen.drainInventoryForRemoval()" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and "if (dropsEnabled) popResource(level, pos, stack)" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and "if (dropsEnabled && net.fybertech.modelcitizens.ModConfigSpecHolder.DROP_MODEL.get())" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", ""),
     "citizen inventory and placer drops must respect vanilla doTileDrops"),
    ("public CompoundTag saveVisualData()" in be and "writeVisualData(tag);" in be
     and 'put("Inventory", inventory.serializeNBT())' not in be.split("public CompoundTag saveVisualData()", 1)[1].split("private void writeVisualData", 1)[0]
     and 'put("ModelCitizensData", visualData)' in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and 'contains("ModelCitizensData", net.minecraft.nbt.Tag.TAG_COMPOUND)' in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "")
     and 'citizen.initializeForPlacement(visualData, placementYaw)' in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "")
     and 'public void initializeForPlacement(CompoundTag visualData, float placementYaw)' in be
     and 'private void readVisualData(CompoundTag tag)' in be,
     "placer restoration must load visual fields only, never inventory NBT from an item tag"),
    ("getCloneItemStack(BlockState state, HitResult target, LevelReader level, BlockPos pos, Player player)" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and 'put("BlockEntityTag", citizen.saveWithoutMetadata())' in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", ""),
     "creative pick-block must duplicate citizen block-entity state and inventory"),
    (sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "").count("level.sendBlockUpdated(pos, state, state, 3);") == 1
     and "citizen.initializeForPlacement(visualData, placementYaw);" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "")
     and "level.sendBlockUpdated(pos, state, state, 3);" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", ""),
     "placer restoration must publish the completed appearance in one final block-entity update"),
    ("NetworkDirection.PLAY_TO_SERVER" in sources.get("src/main/java/net/fybertech/modelcitizens/network/ModNetwork.java", "")
     and "NetworkDirection.PLAY_TO_CLIENT" in sources.get("src/main/java/net/fybertech/modelcitizens/network/ModNetwork.java", "")
     and "OpenCitizenEditorPacket.class" in sources.get("src/main/java/net/fybertech/modelcitizens/network/ModNetwork.java", "")
     and "OpenCitizenEditorPacket" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
     and "ClientEditor.open(packet.pos" in sources.get("src/main/java/net/fybertech/modelcitizens/network/OpenCitizenEditorPacket.java", ""),
     "editor screen must open from a server-approved clientbound packet, with explicit packet directions"),
    ("if (level.isClientSide)" not in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "").split("if (player.isShiftKeyDown()", 1)[-1].split("return InteractionResult.SUCCESS", 1)[0]
     and "MODIFY_IN_SURVIVAL" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", ""),
     "client must not open the editor before server-side survival permission validation"),
    ("if (size != 7)" in sources.get("src/main/java/net/fybertech/modelcitizens/network/OpenCitizenEditorPacket.java", "")
     and "Character.isHighSurrogate" in sources.get("src/main/java/net/fybertech/modelcitizens/network/OpenCitizenEditorPacket.java", ""),
     "server-approved editor-open packet must bound strings and reject malformed pose sizes"),
    ("private void applyPose(float yaw, float scale, float[] values)" in be
     and "java.util.Arrays.fill(pose, 0.0F);" in be,
     "applying a short or null pose must reset missing values instead of retaining stale rotations"),
    ("if (freeSlot < 0 && !occupied[HAND_SLOT]) freeSlot = HAND_SLOT;" in be
     and "Prefer ordinary inventory slots" in be
     and "Do not overwrite a legitimate entry to make room." in be,
     "duplicate-slot recovery must use the dedicated hand slot when the main inventory is full, without overwriting valid items"),
    ("screen.modelcitizens.editor.reset_pose" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "private void resetPose()" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "new float[CitizenBlockEntity.POSE_SIZE]" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "screen.modelcitizens.editor.reset_pose" in (english or {})
     and "screen.modelcitizens.editor.reset_pose" in (russian or {}),
     "pose editor must offer a localized reset action without discarding other unsaved fields"),
    ("poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "poseStack.mulPose(Axis.YP.rotationDegrees(-18.0F));" not in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", ""),
     "editor preview must use the adjustable world yaw instead of a fixed display angle"),
    ("private PlayerModel<LivingEntity> previewPlayerModel;" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "private SkeletonModel<Skeleton> previewSkeletonModel;" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "new PlayerModel<>(entityModels.bakeLayer(ModelLayers.PLAYER), false)" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "new SkeletonModel<>(entityModels.bakeLayer(ModelLayers.SKELETON))" in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
     and "new PlayerModel<>(minecraft.getEntityModels().bakeLayer(ModelLayers.PLAYER), false)" not in sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", ""),
     "editor preview models should be baked once per screen initialization, not recreated every frame"),
    ("net.minecraftforge.gradle" in build, "ForgeGradle plugin declaration missing"),
    ("JavaLanguageVersion.of(17)" in build, "Java 17 toolchain declaration missing"),
    ("citizen.initializeForPlacement(visualData, placementYaw);" in sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java", "")
     and "readVisualData(visualData);" in be.split("public void initializeForPlacement(CompoundTag visualData, float placementYaw)", 1)[1].split("private void writeVisualData", 1)[0]
     and "syncToClient();" not in be.split("public void initializeForPlacement(CompoundTag visualData, float placementYaw)", 1)[1].split("private void writeVisualData", 1)[0],
     "placer initialization must preserve inventory and avoid intermediate client syncs"),
    ('versionRange="[1.20.1,1.20.2)"' in mods, "mods.toml must target Minecraft 1.20.1 only"),
    ("pose.translate(0.5D, 1.501D * modelScale, 0.5D);" in sources.get("src/main/java/net/fybertech/modelcitizens/client/CitizenRenderer.java", "")
     and "pose.scale(modelScale, -modelScale, modelScale);" in sources.get("src/main/java/net/fybertech/modelcitizens/client/CitizenRenderer.java", ""),
     "world humanoid rendering must use the vanilla upward-facing root transform and scale its vertical offset"),
]
if not JAVA_FILES:
    errors.append("No Java source files found")
if not JSON_FILES:
    errors.append("No resource JSON files found")

# Invisible block entities should not leave an invisible full-cube collision obstacle.
mod_blocks = sources.get("src/main/java/net/fybertech/modelcitizens/registry/ModBlocks.java", "")
if ".noCollission()" not in mod_blocks:
    errors.append("citizen block should not retain a full-cube physical collision shape")

# The citizen itself renders invisibly in-world, so its inventory icon must not
# misleadingly use the hidden oak-plank placeholder block model.
citizen_item_model = json_data.get("assets/modelcitizens/models/item/citizen.json")
if not isinstance(citizen_item_model, dict) or citizen_item_model.get("parent") != "minecraft:item/generated" or citizen_item_model.get("textures", {}).get("layer0") != "minecraft:item/player_head":
    errors.append("citizen item model should use the player-head icon rather than the invisible placeholder block model")

sanitizer_source = sources.get("src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java", "")
checks.append(("Character.MIN_SURROGATE" in sanitizer_source and "codePoint == 0x2028 || codePoint == 0x2029" in sanitizer_source,
               "display text sanitizer must reject unpaired surrogates and Unicode line/paragraph separators"))
block_source = sources.get("src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java", "")
config_source = sources.get("src/main/java/net/fybertech/modelcitizens/ModConfigSpecHolder.java", "")
mod_source = sources.get("src/main/java/net/fybertech/modelcitizens/ModelCitizens.java", "")
checks.append((".strength(1.5F, 3600000.0F)" in mod_blocks
               and "instanceof ShovelItem" in block_source
               and "ModConfigSpecHolder.INVULNERABLE.get()" in block_source
               and 'define("invulnerable", false)' in config_source
               and "public void onCitizenBreak(BlockEvent.BreakEvent event)" in mod_source
               and "event.setCanceled(true)" in mod_source,
               "citizen blocks must resist explosions and enforce configurable shovel-only survival breaking"))
renderer_source = sources.get("src/main/java/net/fybertech/modelcitizens/client/CitizenRenderer.java", "")
checks.append(("public AABB getRenderBoundingBox(CitizenBlockEntity be)" in renderer_source
               and "double scale = be.scale();" in renderer_source
               and "pos.getY() + 3.0D * scale" in renderer_source,
               "citizen renderer culling bounds must expand with model scale and include the floating label"))
editor_screen_source = sources.get("src/main/java/net/fybertech/modelcitizens/client/PoseEditorScreen.java", "")
checks.append(("compactLayout = width < 640 || height < 360" in editor_screen_source
               and "Math.max(70, Math.min(145, (width - columnGap - 8) / 2))" in editor_screen_source
               and "int secondColumn = left + columnWidth + columnGap" in editor_screen_source
               and "int actionY = compactLayout ? Math.min(280, Math.max(150, height - 24)) : 280" in editor_screen_source
               and "int compactSliderHeight" in editor_screen_source
               and "int compactSliderPitch = compactSliderHeight + 3" in editor_screen_source
               and "if (!compactLayout)" in editor_screen_source,
               "pose editor must size its compact columns to the available width and hide the preview when space is limited"))

# The custom inventory screen must keep menu slot positions aligned with its drawn outlines.
menu_source = sources.get("src/main/java/net/fybertech/modelcitizens/menu/CitizenMenu.java", "")
screen_source = sources.get("src/main/java/net/fybertech/modelcitizens/client/CitizenScreen.java", "")
layout_checks = [
    ("36 + i, 8, 28 + i * 18" in menu_source and "topPos + 27 + i * 18" in screen_source, "armor slot coordinates must match the screen outlines"),
    ("80 + col * 18, 28 + row * 18" in menu_source and "topPos + 27 + row * 18" in screen_source, "citizen inventory coordinates must match the screen outlines"),
    ("handler, 40, 8, 108" in menu_source and "topPos + 107" in screen_source, "held-item slot coordinates must match the screen outline"),
    ("154 + row * 18" in menu_source and "topPos + 153 + row * 18" in screen_source, "player inventory coordinates must match the screen outlines"),
    ("playerInventory, col, 8 + col * 18, 212" in menu_source and "topPos + 211" in screen_source and "this.imageHeight = 238" in screen_source, "hotbar must fit inside the expanded inventory screen"),
]
for ok, message in layout_checks:
    if not ok:
        errors.append("GUI layout invariant failed: " + message)



# Evaluate every invariant only after all late-added checks have been registered.
for ok, message in checks:
    if not ok:
        errors.append(message)

if errors:
    print("\n".join(f"ERROR: {error}" for error in errors))
    sys.exit(1)

print(f"Static checks passed: {len(JAVA_FILES)} Java files, {len(JSON_FILES)} JSON files.")
print(f"Structural checks passed: {len(checks) + len(layout_checks)} project/API invariants.")
print("Resource checks passed: JSON syntax, model references, bilingual UI keys, item translations, and placer recipe.")
print("Java delimiter checks ignore comments and literals; this is not a Java compiler.")
print("Run `bash scripts/build_mod.sh` with JDK 17 to verify actual Forge compilation.")
