package net.fybertech.modelcitizens.util;

/** Pure-Java sanitizer for single-line citizen labels and persisted identity text. */
public final class CitizenTextSanitizer {
    private CitizenTextSanitizer() { }

    /**
     * Trim text, remove control and bidi formatting characters, and cap the result
     * by Unicode code points (not UTF-16 code units) so supplementary characters
     * such as emoji are not split in half.
     */
    public static String sanitizeSingleLine(String value, int maxCodePoints) {
        if (value == null || value.isBlank() || maxCodePoints <= 0) return "";
        String cleaned = value.strip();
        StringBuilder safe = new StringBuilder(Math.min(cleaned.length(), maxCodePoints));
        int count = 0;
        for (int offset = 0; offset < cleaned.length() && count < maxCodePoints;) {
            int codePoint = cleaned.codePointAt(offset);
            offset += Character.charCount(codePoint);
            // A lone UTF-16 surrogate is not a Unicode scalar value. Valid
            // supplementary characters arrive as one code point above U+FFFF.
            // Also remove Unicode line/paragraph separators so this stays a
            // single-line label even when text originates in edited NBT.
            if (Character.isISOControl(codePoint)
                    || (codePoint >= Character.MIN_SURROGATE && codePoint <= Character.MAX_SURROGATE)
                    || codePoint == 0x2028 || codePoint == 0x2029
                    || isBidiControl(codePoint)) continue;
            safe.appendCodePoint(codePoint);
            count++;
        }
        return safe.toString().strip();
    }

    private static boolean isBidiControl(int codePoint) {
        return codePoint == 0x061C || codePoint == 0x200E || codePoint == 0x200F
            || (codePoint >= 0x202A && codePoint <= 0x202E)
            || (codePoint >= 0x2066 && codePoint <= 0x2069);
    }
}
