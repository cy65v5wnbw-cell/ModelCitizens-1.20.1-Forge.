package net.fybertech.modelcitizens.registry;

import net.fybertech.modelcitizens.ModelCitizens;
import net.fybertech.modelcitizens.world.CitizenBlockEntity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ModelCitizens.MODID);
    public static final RegistryObject<BlockEntityType<CitizenBlockEntity>> CITIZEN = TYPES.register("citizen",
        () -> BlockEntityType.Builder.of(CitizenBlockEntity::new, ModBlocks.CITIZEN.get()).build(null));
    private ModBlockEntities() {}
}
