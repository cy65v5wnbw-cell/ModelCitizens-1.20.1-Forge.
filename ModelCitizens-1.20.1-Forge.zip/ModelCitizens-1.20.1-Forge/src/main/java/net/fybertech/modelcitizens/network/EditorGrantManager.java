package net.fybertech.modelcitizens.network;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.fybertech.modelcitizens.world.CitizenBlockEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Server-memory-only, short-lived permission to edit one citizen. */
public final class EditorGrantManager {
    private static final long GRANT_TICKS = 200L;
    private static final Map<UUID, Grant> GRANTS = new HashMap<>();

    private record Grant(long position, String dimension, UUID blockEntityToken, long expiresAt) { }

    private EditorGrantManager() { }

    /** Called only after the server has observed an explicit interaction with a citizen. */
    public static void issue(Player player, Level level, CitizenBlockEntity citizen) {
        if (player == null || level == null || level.isClientSide || citizen == null) return;
        BlockPos pos = citizen.getBlockPos();
        GRANTS.put(player.getUUID(), new Grant(
            pos.asLong(), level.dimension().location().toString(), citizen.editorToken(),
            level.getGameTime() + GRANT_TICKS));
    }

    /** Validate without consuming so malformed packets do not spend a valid grant. */
    public static boolean permits(Player player, Level level, BlockPos pos, CitizenBlockEntity citizen) {
        if (player == null || level == null || level.isClientSide || citizen == null) return false;
        Grant grant = GRANTS.get(player.getUUID());
        if (grant == null) return false;
        if (level.getGameTime() >= grant.expiresAt()
                || !level.dimension().location().toString().equals(grant.dimension())) {
            GRANTS.remove(player.getUUID());
            return false;
        }
        return grant.position() == pos.asLong() && grant.blockEntityToken().equals(citizen.editorToken());
    }

    /** Consume after a successful state commit. */
    public static void consume(Player player) {
        if (player != null) GRANTS.remove(player.getUUID());
    }

    /** Clear ephemeral authorization on logout, dimension change, or player removal. */
    public static void clear(Player player) {
        if (player != null) GRANTS.remove(player.getUUID());
    }

    /** Avoid carrying grants across integrated/dedicated server shutdowns. */
    public static void clearAll() {
        GRANTS.clear();
    }
}
