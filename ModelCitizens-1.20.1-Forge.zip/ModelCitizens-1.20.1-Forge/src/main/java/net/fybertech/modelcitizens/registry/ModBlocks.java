package net.fybertech.modelcitizens.registry;

import net.fybertech.modelcitizens.ModelCitizens;
import net.fybertech.modelcitizens.world.CitizenBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ModelCitizens.MODID);
    public static final RegistryObject<Block> CITIZEN = BLOCKS.register("citizen",
        () -> new CitizenBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(1.5F, 3600000.0F).noOcclusion().noCollission()));
    private ModBlocks() {}
}
