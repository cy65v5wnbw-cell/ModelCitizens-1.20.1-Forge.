package net.fybertech.modelcitizens.network;

import net.fybertech.modelcitizens.ModelCitizens;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.network.NetworkDirection;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(ModelCitizens.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0, SetCitizenPosePacket.class, SetCitizenPosePacket::encode,
            SetCitizenPosePacket::decode, SetCitizenPosePacket::handle, NetworkDirection.PLAY_TO_SERVER);
        CHANNEL.registerMessage(1, OpenCitizenEditorPacket.class, OpenCitizenEditorPacket::encode,
            OpenCitizenEditorPacket::decode, OpenCitizenEditorPacket::handle, NetworkDirection.PLAY_TO_CLIENT);
    }
    private ModNetwork() {}
}
