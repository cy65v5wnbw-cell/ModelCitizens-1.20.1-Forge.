package net.fybertech.modelcitizens.network;

import net.fybertech.modelcitizens.world.CitizenBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class SetCitizenPosePacket {
    private final BlockPos pos;
    private final float yaw, scale;
    private final float[] pose;
    private final String texture, name;
    private final int modelType;

    public SetCitizenPosePacket(BlockPos pos, float yaw, float scale, float[] pose, String texture, String name, int modelType) {
        this.pos = pos;
        this.yaw = yaw;
        this.scale = scale;
        // Keep locally-created packets in the same fixed-size format accepted by decode.
        // Copy only the supported values so callers cannot mutate the payload after creation.
        this.pose = new float[CitizenBlockEntity.POSE_SIZE];
        if (pose != null) {
            System.arraycopy(pose, 0, this.pose, 0, Math.min(pose.length, this.pose.length));
        }
        // FriendlyByteBuf.writeUtf(..., 64) rejects oversized strings. Bound them
        // here so a long value from a UI or another caller cannot break packet encoding.
        this.texture = boundedUtf(texture, 64);
        this.name = boundedUtf(name, 64);
        this.modelType = Math.max(0, Math.min(1, modelType));
    }

    private static String boundedUtf(String value, int maxLength) {
        if (value == null || value.isEmpty()) return "";
        int end = Math.min(value.length(), maxLength);
        // Do not leave a dangling high surrogate when truncating a supplementary character.
        if (end > 0 && end < value.length()
                && Character.isHighSurrogate(value.charAt(end - 1))
                && Character.isLowSurrogate(value.charAt(end))) {
            end--;
        }
        return value.substring(0, end);
    }
    public static void encode(SetCitizenPosePacket p, FriendlyByteBuf b) {
        b.writeBlockPos(p.pos); b.writeFloat(p.yaw); b.writeFloat(p.scale);
        b.writeVarInt(p.pose.length); for (float f : p.pose) b.writeFloat(f);
        b.writeUtf(p.texture, 64); b.writeUtf(p.name, 64); b.writeVarInt(p.modelType);
    }
    public static SetCitizenPosePacket decode(FriendlyByteBuf b) {
        BlockPos pos = b.readBlockPos(); float yaw = b.readFloat(), scale = b.readFloat();
        int n = b.readVarInt();
        // Reject malformed packets rather than allocating from an untrusted length.
        if (n != CitizenBlockEntity.POSE_SIZE) throw new IllegalArgumentException("Invalid citizen pose length: " + n);
        float[] pose = new float[n];
        for (int i = 0; i < n; i++) pose[i] = b.readFloat();
        return new SetCitizenPosePacket(pos, yaw, scale, pose, b.readUtf(64), b.readUtf(64), b.readVarInt());
    }
    public static void handle(SetCitizenPosePacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null || player.level().isClientSide
                || player.distanceToSqr(p.pos.getX()+0.5, p.pos.getY()+0.5, p.pos.getZ()+0.5) > 64
                || !player.mayBuild()) return;
            // The pose editor is a standalone Screen, so the player's active
            // container is not CitizenMenu. Require a recent server-observed
            // interaction with this exact block-entity instance instead of relying
            // only on coordinates (a citizen may have been replaced at the same pos).
            if (!player.isCreative() && !net.fybertech.modelcitizens.ModConfigSpecHolder.MODIFY_IN_SURVIVAL.get()) return;
            // Reject positions outside the world's legal bounds before querying state.
            if (!player.level().isInWorldBounds(p.pos) || !player.level().hasChunkAt(p.pos)) return;
            if (!player.level().getBlockState(p.pos).is(net.fybertech.modelcitizens.registry.ModBlocks.CITIZEN.get())) return;
            if (!Float.isFinite(p.yaw) || !Float.isFinite(p.scale)) return;
            for (float value : p.pose) if (!Float.isFinite(value)) return;
            BlockEntity be = player.level().getBlockEntity(p.pos);
            if (be instanceof CitizenBlockEntity citizen
                    && EditorGrantManager.permits(player, player.level(), p.pos, citizen)) {
                // Keep the packet bounded and only accept a resource-location texture ID.
                String texture = p.texture == null ? "" : p.texture.trim();
                if (texture.length() > 64) texture = texture.substring(0, 64);
                if (!texture.isEmpty() && (net.minecraft.resources.ResourceLocation.tryParse(texture) == null
                        || !net.fybertech.modelcitizens.util.CitizenTexturePathPolicy.isSafeTextureId(texture))) {
                    texture = "";
                }
                String name = p.name == null ? "" : p.name;
                if (name.length() > 64) name = name.substring(0, 64);
                // Commit the complete editor state atomically to avoid two block updates
                // (one for identity and another for pose) for a single user action.
                citizen.applyEditorState(texture, name, p.modelType, p.yaw, p.scale, p.pose);
                // One editor save is one grant; the next edit requires a fresh
                // interaction, preventing stale authorization from being reused.
                EditorGrantManager.consume(player);
            }
        });
        c.setPacketHandled(true);
    }
}
