#!/usr/bin/env python3
"""Compile and exercise the production pure-Java text sanitizer without Forge dependencies."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java"

HARNESS = r'''import net.fybertech.modelcitizens.util.CitizenTextSanitizer;

public final class CitizenTextSanitizerTest {
    private static void equal(String expected, String actual, String message) {
        if (!expected.equals(actual)) {
            throw new AssertionError(message + ": expected [" + expected + "], got [" + actual + "]");
        }
    }

    public static void main(String[] args) {
        equal("", CitizenTextSanitizer.sanitizeSingleLine(null, 64), "null input");
        equal("", CitizenTextSanitizer.sanitizeSingleLine(" \t\n ", 64), "blank input");
        equal("AliceBob", CitizenTextSanitizer.sanitizeSingleLine("Alice\nBob", 64), "line break removal");
        equal("safe-name", CitizenTextSanitizer.sanitizeSingleLine("safe\u202E-name", 64), "bidi override removal");
        equal("😀A", CitizenTextSanitizer.sanitizeSingleLine("😀AB", 2), "code-point length cap");
        equal("😀", CitizenTextSanitizer.sanitizeSingleLine("😀", 1), "supplementary character preservation");
        equal("A", CitizenTextSanitizer.sanitizeSingleLine("A\u0000B", 1), "control removal before length cap");
        equal("", CitizenTextSanitizer.sanitizeSingleLine("abc", 0), "zero length cap");
        equal("AB", CitizenTextSanitizer.sanitizeSingleLine("A\u2028B", 64), "Unicode line separator removal");
        equal("AB", CitizenTextSanitizer.sanitizeSingleLine("A\u2029B", 64), "Unicode paragraph separator removal");
        equal("AB", CitizenTextSanitizer.sanitizeSingleLine("A\uD800B", 64), "unpaired surrogate removal");
        System.out.println("Production text sanitizer: 11 behavioral tests passed.");
    }
}
'''


class TextSanitizerTests(unittest.TestCase):
    def test_production_java_sanitizer(self) -> None:
        javac = shutil.which("javac")
        java = shutil.which("java")
        if not javac or not java:
            self.skipTest("JDK not available; pure-Java sanitizer behavior could not be executed")
        with tempfile.TemporaryDirectory(prefix="modelcitizens-text-test-") as temp:
            temp_path = Path(temp)
            harness = temp_path / "CitizenTextSanitizerTest.java"
            harness.write_text(HARNESS, encoding="utf-8")
            subprocess.run(
                [javac, "-encoding", "UTF-8", "-d", str(temp_path), str(SOURCE), str(harness)],
                check=True, capture_output=True, text=True,
            )
            result = subprocess.run(
                [java, "-cp", str(temp_path), "CitizenTextSanitizerTest"],
                check=True, capture_output=True, text=True,
            )
            self.assertIn("11 behavioral tests passed", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
