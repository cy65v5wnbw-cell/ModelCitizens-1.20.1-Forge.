package net.fybertech.modelcitizens.network;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server-authoritative response that opens the editor only after permission checks pass. */
public final class OpenCitizenEditorPacket {
    private final BlockPos pos;
    private final String texture;
    private final String displayName;
    private final int modelType;
    private final float yaw;
    private final float scale;
    private final float[] pose;

    public OpenCitizenEditorPacket(BlockPos pos, String texture, String displayName,
                                   int modelType, float yaw, float scale, float[] pose) {
        this.pos = pos;
        this.texture = bounded(texture, 64);
        this.displayName = bounded(displayName, 64);
        this.modelType = Math.max(0, Math.min(1, modelType));
        this.yaw = Float.isFinite(yaw) ? yaw : 0.0F;
        this.scale = Float.isFinite(scale) ? scale : 1.0F;
        this.pose = new float[7];
        if (pose != null) {
            for (int i = 0; i < Math.min(pose.length, this.pose.length); i++) {
                this.pose[i] = Float.isFinite(pose[i]) ? pose[i] : 0.0F;
            }
        }
    }

    private static String bounded(String value, int max) {
        if (value == null || value.isEmpty()) return "";
        int end = Math.min(value.length(), max);
        if (end > 0 && end < value.length()
                && Character.isHighSurrogate(value.charAt(end - 1))
                && Character.isLowSurrogate(value.charAt(end))) end--;
        return value.substring(0, end);
    }

    public static void encode(OpenCitizenEditorPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBlockPos(packet.pos);
        buffer.writeUtf(packet.texture, 64);
        buffer.writeUtf(packet.displayName, 64);
        buffer.writeVarInt(packet.modelType);
        buffer.writeFloat(packet.yaw);
        buffer.writeFloat(packet.scale);
        buffer.writeVarInt(packet.pose.length);
        for (float value : packet.pose) buffer.writeFloat(value);
    }

    public static OpenCitizenEditorPacket decode(FriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        String texture = buffer.readUtf(64);
        String displayName = buffer.readUtf(64);
        int modelType = buffer.readVarInt();
        float yaw = buffer.readFloat();
        float scale = buffer.readFloat();
        int size = buffer.readVarInt();
        if (size != 7) throw new IllegalArgumentException("Invalid editor pose length: " + size);
        float[] pose = new float[size];
        for (int i = 0; i < size; i++) pose[i] = buffer.readFloat();
        return new OpenCitizenEditorPacket(pos, texture, displayName, modelType, yaw, scale, pose);
    }

    public static void handle(OpenCitizenEditorPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            net.fybertech.modelcitizens.client.ClientEditor.open(packet.pos, packet.texture,
                packet.displayName, packet.modelType, packet.yaw, packet.scale, packet.pose)));
        context.setPacketHandled(true);
    }
}
