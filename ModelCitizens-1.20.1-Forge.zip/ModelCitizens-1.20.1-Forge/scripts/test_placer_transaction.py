#!/usr/bin/env python3
"""Regression guards for transactional server-side citizen placement."""
from __future__ import annotations
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenPlacerItem.java").read_text(encoding="utf-8")


class PlacerTransactionTests(unittest.TestCase):
    def test_client_prediction_returns_before_server_mutation(self) -> None:
        client_return = SOURCE.index("if (level.isClientSide) return InteractionResult.SUCCESS;")
        set_block = SOURCE.index("level.setBlock(pos, state, 3)")
        self.assertLess(client_return, set_block)

    def test_failed_set_block_returns_failure_before_consuming_item(self) -> None:
        failed_placement = SOURCE.index("if (!level.setBlock(pos, state, 3)) return InteractionResult.FAIL;")
        shrink = SOURCE.index("context.getItemInHand().shrink(1)")
        self.assertLess(failed_placement, shrink)
        self.assertIn("return InteractionResult.CONSUME;", SOURCE[shrink:])

    def test_missing_block_entity_rolls_back_and_preserves_item(self) -> None:
        set_block = SOURCE.index("if (!level.setBlock(pos, state, 3)) return InteractionResult.FAIL;")
        missing_entity = SOURCE.index("if (!(level.getBlockEntity(pos) instanceof CitizenBlockEntity citizen))")
        rollback = SOURCE.index("&& level.setBlock(pos, previousState, 3)", missing_entity)
        failure = SOURCE.index("return InteractionResult.FAIL;", rollback)
        shrink = SOURCE.index("context.getItemInHand().shrink(1)")
        self.assertLess(set_block, missing_entity)
        self.assertLess(missing_entity, rollback)
        self.assertLess(rollback, failure)
        self.assertLess(failure, shrink)
        self.assertIn("BlockState previousState = level.getBlockState(pos);", SOURCE)

    def test_success_path_consumes_only_after_entity_is_initialized(self) -> None:
        entity_guard = SOURCE.index("if (!(level.getBlockEntity(pos) instanceof CitizenBlockEntity citizen))")
        appearance_commit = SOURCE.index("citizen.initializeForPlacement(visualData, placementYaw);", entity_guard)
        shrink = SOURCE.index("context.getItemInHand().shrink(1)")
        self.assertLess(entity_guard, appearance_commit)
        self.assertLess(appearance_commit, shrink)
        self.assertEqual(SOURCE.count("context.getItemInHand().shrink(1)"), 1)

    def test_rollback_restores_replaced_block_entity_data(self) -> None:
        snapshot = SOURCE.index("CompoundTag previousBlockEntityTag = previousBlockEntity == null")
        rollback = SOURCE.index("&& level.setBlock(pos, previousState, 3)", snapshot)
        restore = SOURCE.index("restored.load(previousBlockEntityTag);", rollback)
        mark_changed = SOURCE.index("restored.setChanged();", restore)
        publish = SOURCE.index("level.sendBlockUpdated(pos, previousState, previousState, 3);", mark_changed)
        self.assertLess(snapshot, rollback)
        self.assertLess(rollback, restore)
        self.assertLess(restore, mark_changed)
        self.assertLess(mark_changed, publish)
        self.assertIn("previousBlockEntity.saveWithoutMetadata()", SOURCE)


    def test_placement_initializes_appearance_before_one_final_sync(self) -> None:
        initialize = SOURCE.index("citizen.initializeForPlacement(visualData, placementYaw);")
        publish = SOURCE.index("level.sendBlockUpdated(pos, state, state, 3);", initialize)
        sound = SOURCE.index("level.playSound(null, pos", publish)
        self.assertLess(initialize, publish)
        self.assertLess(publish, sound)
        self.assertEqual(SOURCE.count("level.sendBlockUpdated(pos, state, state, 3);"), 1)
        self.assertNotIn("citizen.loadVisualData(", SOURCE)
        self.assertNotIn("citizen.setPose(", SOURCE)

    def test_placement_feedback_occurs_only_after_successful_initialization(self) -> None:
        entity_guard = SOURCE.index("if (!(level.getBlockEntity(pos) instanceof CitizenBlockEntity citizen))")
        failure_return = SOURCE.index("return InteractionResult.FAIL;", entity_guard)
        sound = SOURCE.index("level.playSound(null, pos", failure_return)
        game_event = SOURCE.index("level.gameEvent(context.getPlayer(), GameEvent.BLOCK_PLACE, pos);", sound)
        shrink = SOURCE.index("context.getItemInHand().shrink(1)", game_event)
        self.assertLess(failure_return, sound)
        self.assertLess(sound, game_event)
        self.assertLess(game_event, shrink)
        self.assertIn("SoundSource.BLOCKS", SOURCE[sound:game_event])


if __name__ == "__main__":
    unittest.main(verbosity=2)
