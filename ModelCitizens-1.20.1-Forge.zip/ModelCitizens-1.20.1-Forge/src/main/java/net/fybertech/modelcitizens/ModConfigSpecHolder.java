package net.fybertech.modelcitizens;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ModConfigSpecHolder {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec.BooleanValue DROP_MODEL;
    public static final ForgeConfigSpec.BooleanValue INVULNERABLE;
    public static final ForgeConfigSpec.BooleanValue MODIFY_IN_SURVIVAL;
    public static final ForgeConfigSpec.BooleanValue SURVIVAL_CAN_INSERT;
    public static final ForgeConfigSpec SPEC;
    static {
        B.push("general");
        DROP_MODEL = B.comment("Drop a placer item when a citizen is broken").define("dropModel", true);
        INVULNERABLE = B.comment("Prevent survival players from breaking citizens; creative mode can still remove them").define("invulnerable", false);
        MODIFY_IN_SURVIVAL = B.comment("Allow editing pose/configuration in survival").define("modifyInSurvival", true);
        SURVIVAL_CAN_INSERT = B.comment("Allow inserting items into the citizen inventory in survival").define("survivalCanInsert", true);
        B.pop();
        SPEC = B.build();
    }
    private ModConfigSpecHolder() {}
}
