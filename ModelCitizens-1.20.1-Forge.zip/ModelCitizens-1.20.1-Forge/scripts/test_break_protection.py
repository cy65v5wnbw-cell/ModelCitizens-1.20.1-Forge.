#!/usr/bin/env python3
"""Regression guards for the legacy shovel-only and explosion-resistant citizen behavior."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
BLOCK = (ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java").read_text(encoding="utf-8")
REGISTRY = (ROOT / "src/main/java/net/fybertech/modelcitizens/registry/ModBlocks.java").read_text(encoding="utf-8")
MOD = (ROOT / "src/main/java/net/fybertech/modelcitizens/ModelCitizens.java").read_text(encoding="utf-8")
CONFIG = (ROOT / "src/main/java/net/fybertech/modelcitizens/ModConfigSpecHolder.java").read_text(encoding="utf-8")
RENDERER = (ROOT / "src/main/java/net/fybertech/modelcitizens/client/CitizenRenderer.java").read_text(encoding="utf-8")
README = (ROOT / "README.md").read_text(encoding="utf-8")


class BreakProtectionTests(unittest.TestCase):
    def test_citizens_have_high_explosion_resistance(self) -> None:
        self.assertIn(".strength(1.5F, 3600000.0F)", REGISTRY)

    def test_survival_destroy_progress_requires_shovel(self) -> None:
        method_start = BLOCK.index("@Override public float getDestroyProgress(")
        method_end = BLOCK.index("/** Creative pick-block", method_start)
        method = BLOCK[method_start:method_end]
        self.assertIn("player.isCreative()", method)
        self.assertIn("ModConfigSpecHolder.INVULNERABLE.get()", method)
        self.assertIn("instanceof ShovelItem", method)
        self.assertIn("return super.getDestroyProgress(state, player, level, pos);", method)

    def test_break_event_blocks_non_shovel_and_invulnerable_survival_breaks(self) -> None:
        start = MOD.index("public void onCitizenBreak(BlockEvent.BreakEvent event)")
        end = MOD.index("// Grants live only in server memory", start)
        method = MOD[start:end]
        self.assertIn("event.getState().is(ModBlocks.CITIZEN.get())", method)
        self.assertIn("event.getPlayer().isCreative()", method)
        self.assertIn("ModConfigSpecHolder.INVULNERABLE.get()", method)
        self.assertIn("instanceof ShovelItem", method)
        self.assertIn("event.setCanceled(true)", method)

    def test_config_and_documentation_describe_the_setting(self) -> None:
        self.assertIn('define("invulnerable", false)', CONFIG)
        self.assertIn("general.invulnerable", README)
        self.assertIn("explosion-resistant", README)

    def test_scaled_citizens_receive_expanded_render_culling_bounds(self) -> None:
        self.assertIn("public AABB getRenderBoundingBox(CitizenBlockEntity be)", RENDERER)
        self.assertIn("double scale = be.scale();", RENDERER)
        self.assertIn("pos.getY() + 3.0D * scale", RENDERER)


if __name__ == "__main__":
    unittest.main(verbosity=2)
