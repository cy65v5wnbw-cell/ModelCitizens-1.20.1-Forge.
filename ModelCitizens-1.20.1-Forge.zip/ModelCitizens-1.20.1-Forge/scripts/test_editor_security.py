#!/usr/bin/env python3
"""Source-level security regression checks for the editor network path.

These checks guard critical authorization invariants; they are not runtime Forge tests.
"""
from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCES = {
    "pose_packet": ROOT / "src/main/java/net/fybertech/modelcitizens/network/SetCitizenPosePacket.java",
    "grant_manager": ROOT / "src/main/java/net/fybertech/modelcitizens/network/EditorGrantManager.java",
    "mod": ROOT / "src/main/java/net/fybertech/modelcitizens/ModelCitizens.java",
    "block": ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenBlock.java",
}


def source(name: str) -> str:
    return SOURCES[name].read_text(encoding="utf-8")


class EditorSecuritySourceTests(unittest.TestCase):
    def test_packet_requires_server_sender_and_build_permission(self) -> None:
        code = source("pose_packet")
        self.assertIn("ServerPlayer player = c.getSender()", code)
        self.assertIn("player == null || player.level().isClientSide", code)
        self.assertIn("!player.mayBuild()", code)

    def test_packet_checks_distance_world_bounds_and_loaded_chunk(self) -> None:
        code = source("pose_packet")
        self.assertIn("player.distanceToSqr", code)
        self.assertIn("!player.level().isInWorldBounds(p.pos)", code)
        self.assertIn("!player.level().hasChunkAt(p.pos)", code)

    def test_packet_requires_citizen_and_instance_bound_grant(self) -> None:
        code = source("pose_packet")
        self.assertIn("getBlockState(p.pos).is(net.fybertech.modelcitizens.registry.ModBlocks.CITIZEN.get())", code)
        self.assertIn("EditorGrantManager.permits(player, player.level(), p.pos, citizen)", code)
        self.assertIn("EditorGrantManager.consume(player)", code)

    def test_non_finite_pose_values_are_rejected_before_commit(self) -> None:
        code = source("pose_packet")
        self.assertIn("if (!Float.isFinite(p.yaw) || !Float.isFinite(p.scale)) return;", code)
        self.assertIn("for (float value : p.pose) if (!Float.isFinite(value)) return;", code)
        self.assertLess(code.index("if (!Float.isFinite(p.yaw)"), code.index("citizen.applyEditorState("))

    def test_grant_is_short_lived_and_bound_to_block_entity_token(self) -> None:
        code = source("grant_manager")
        self.assertIn("private static final long GRANT_TICKS = 200L", code)
        self.assertIn("citizen.editorToken()", code)
        self.assertIn("grant.blockEntityToken().equals(citizen.editorToken())", code)
        self.assertIn("level.getGameTime() >= grant.expiresAt()", code)

    def test_grants_are_cleared_on_session_transitions(self) -> None:
        code = source("mod")
        self.assertIn("PlayerLoggedOutEvent", code)
        self.assertIn("PlayerChangedDimensionEvent", code)
        self.assertIn("PlayerRespawnEvent", code)
        self.assertIn("ServerStoppingEvent", code)
        self.assertIn("EditorGrantManager.clearAll()", code)

    def test_editor_open_requires_build_permission_and_server_authority(self) -> None:
        code = source("block")
        self.assertIn("if (!player.mayBuild()) return InteractionResult.CONSUME;", code)
        self.assertIn("EditorGrantManager.issue(player, level, citizen)", code)
        self.assertIn("if (!level.isClientSide)", code)

    def test_saved_display_text_rejects_control_and_bidi_override_characters(self) -> None:
        code = (ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java").read_text(encoding="utf-8")
        sanitizer = (ROOT / "src/main/java/net/fybertech/modelcitizens/util/CitizenTextSanitizer.java").read_text(encoding="utf-8")
        self.assertIn("CitizenTextSanitizer.sanitizeSingleLine(value, maxLength)", code)
        self.assertIn("Character.isISOControl(codePoint)", sanitizer)
        self.assertIn("isBidiControl(codePoint)", sanitizer)
        self.assertIn("safe.appendCodePoint(codePoint)", sanitizer)


if __name__ == "__main__":
    unittest.main(verbosity=2)
