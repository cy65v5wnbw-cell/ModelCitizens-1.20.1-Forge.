package net.fybertech.modelcitizens.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.fybertech.modelcitizens.ModelCitizens;
import net.fybertech.modelcitizens.util.CitizenTexturePathPolicy;
import net.fybertech.modelcitizens.registry.ModBlockEntities;
import net.fybertech.modelcitizens.world.CitizenBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.DyeableLeatherItem;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemTransforms;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ModelCitizens.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class CitizenRenderer implements BlockEntityRenderer<CitizenBlockEntity> {
    private final PlayerModel<LivingEntity> playerModel;
    private final SkeletonModel<Skeleton> skeletonModel;
    private final HumanoidModel<LivingEntity> innerArmorModel;
    private final HumanoidModel<LivingEntity> outerArmorModel;

    public CitizenRenderer(BlockEntityRendererProvider.Context context) {
        EntityModelSet models = context.getModelSet();
        playerModel = new PlayerModel<>(models.bakeLayer(ModelLayers.PLAYER), false);
        skeletonModel = new SkeletonModel<>(models.bakeLayer(ModelLayers.SKELETON));
        innerArmorModel = new HumanoidModel<>(models.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR));
        outerArmorModel = new HumanoidModel<>(models.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.CITIZEN.get(), CitizenRenderer::new);
    }

    /** Expand culling bounds for the scaled humanoid and its floating display label. */
    @Override
    public AABB getRenderBoundingBox(CitizenBlockEntity be) {
        BlockPos pos = be.getBlockPos();
        double scale = be.scale();
        return new AABB(
            pos.getX() + 0.5D - scale, pos.getY() - 0.25D, pos.getZ() + 0.5D - scale,
            pos.getX() + 0.5D + scale, pos.getY() + 3.0D * scale, pos.getZ() + 0.5D + scale);
    }

    /**
     * Texture names are stored as resource locations, e.g.
     * "modelcitizens:textures/entity/my_citizen.png". Empty or invalid values
     * fall back to the vanilla texture for the selected model.
     */
    private static ResourceLocation resolveTexture(CitizenBlockEntity be) {
        String value = be.textureName();
        if (value != null && !value.isBlank()) {
            ResourceLocation parsed = ResourceLocation.tryParse(value.trim());
            if (isTextureResource(parsed)
                    && Minecraft.getInstance().getResourceManager().getResource(parsed).isPresent()) {
                return parsed;
            }
        }
        return be.modelType() == 1
            ? new ResourceLocation("minecraft", "textures/entity/skeleton/skeleton.png")
            : DefaultPlayerSkin.getDefaultSkin();
    }

    /** Accept only PNG resources in a texture namespace path, never arbitrary JSON/data files. */
    private static boolean isTextureResource(ResourceLocation location) {
        return location != null && CitizenTexturePathPolicy.isSafeTextureLocation(location.getNamespace(), location.getPath());
    }

    private static ResourceLocation armorTexture(ArmorMaterial material, boolean leggings) {
        String materialName = material.getName();
        ResourceLocation materialId = ResourceLocation.tryParse(materialName);
        if (materialId == null) materialId = new ResourceLocation("minecraft", materialName);
        return new ResourceLocation(materialId.getNamespace(),
            "textures/models/armor/" + materialId.getPath() + (leggings ? "_layer_2.png" : "_layer_1.png"));
    }

    private static void renderArmorPart(HumanoidModel<LivingEntity> model, EquipmentSlot slot,
                                        PoseStack pose, com.mojang.blaze3d.vertex.VertexConsumer vertex,
                                        int packedLight, float red, float green, float blue) {
        switch (slot) {
            case HEAD -> {
                // Vanilla helmet geometry includes both the head and the outer hat part.
                // Rendering only the head omits the helmet's outer layer on humanoid models.
                model.head.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
                model.hat.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
            }
            case CHEST -> {
                model.body.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
                model.leftArm.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
                model.rightArm.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
            }
            case LEGS -> {
                model.body.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
                model.leftLeg.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
                model.rightLeg.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
            }
            case FEET -> {
                model.leftLeg.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
                model.rightLeg.render(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, red, green, blue, 1F);
            }
            default -> { }
        }
    }

    @Override
    public void render(CitizenBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers, int packedLight, int packedOverlay) {
        EntityModel<?> model = be.modelType() == 1 ? skeletonModel : playerModel;
        ResourceLocation texture = resolveTexture(be);
        pose.pushPose();
        // Vanilla humanoid model coordinates point downward on +Y and are measured
        // in sixteenths of a block. Match LivingEntityRenderer's root transform so
        // the feet sit on the block top and the head renders above ground, while the
        // configured scale affects both the model and its vertical root offset.
        float modelScale = be.scale();
        pose.translate(0.5D, 1.501D * modelScale, 0.5D);
        pose.mulPose(Axis.YP.rotationDegrees(-be.modelYaw()));
        pose.scale(modelScale, -modelScale, modelScale);

        HumanoidModel<LivingEntity> handModel = null;
        if (model instanceof HumanoidModel<?> raw) {
            @SuppressWarnings("unchecked")
            HumanoidModel<LivingEntity> humanoid = (HumanoidModel<LivingEntity>) raw;
            handModel = humanoid;
            float[] p = be.pose();
            humanoid.head.yRot = (float)Math.toRadians(p[0]);
            humanoid.head.xRot = (float)Math.toRadians(p[1]);
            humanoid.body.yRot = (float)Math.toRadians(p[2]);
            humanoid.leftArm.xRot = (float)Math.toRadians(p[3]);
            humanoid.rightArm.xRot = (float)Math.toRadians(p[4]);
            humanoid.leftLeg.xRot = (float)Math.toRadians(p[5]);
            humanoid.rightLeg.xRot = (float)Math.toRadians(p[6]);
            // Humanoid parts are sibling model parts rather than children of the
            // torso. Mirror vanilla's setupAnim convention so the limbs follow the
            // torso's yaw instead of visually shearing away when body yaw is edited.
            humanoid.leftArm.yRot = humanoid.body.yRot;
            humanoid.rightArm.yRot = humanoid.body.yRot;
            humanoid.leftLeg.yRot = humanoid.body.yRot;
            humanoid.rightLeg.yRot = humanoid.body.yRot;
        }
        var vertex = buffers.getBuffer(RenderType.entityCutoutNoCull(texture));
        model.renderToBuffer(pose, vertex, packedLight, OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, 1F);

        // Render armor from the four equipment slots using vanilla humanoid armor geometry.
        // Leather dye overlays and the standard enchanted glint are supported; armor trims
        // still require the vanilla trim-atlas pipeline and are not rendered here.
        if (model instanceof HumanoidModel<?> rawHumanoid) {
            @SuppressWarnings("unchecked")
            HumanoidModel<LivingEntity> humanoid = (HumanoidModel<LivingEntity>) rawHumanoid;
            humanoid.copyPropertiesTo(innerArmorModel);
            humanoid.copyPropertiesTo(outerArmorModel);
            for (int slot = 36; slot <= 39; slot++) {
                ItemStack armorStack = be.inventory().getStackInSlot(slot);
                if (!(armorStack.getItem() instanceof ArmorItem armor)) continue;
                // Only render a piece in its matching equipment slot. This also
                // prevents malformed or older NBT from drawing boots as a helmet.
                EquipmentSlot expectedSlot = switch (slot) {
                    case 36 -> EquipmentSlot.HEAD;
                    case 37 -> EquipmentSlot.CHEST;
                    case 38 -> EquipmentSlot.LEGS;
                    case 39 -> EquipmentSlot.FEET;
                    default -> null;
                };
                if (expectedSlot == null || armor.getSlot() != expectedSlot) continue;
                HumanoidModel<LivingEntity> armorModel = expectedSlot == EquipmentSlot.LEGS
                    ? innerArmorModel : outerArmorModel;
                boolean leggings = expectedSlot == EquipmentSlot.LEGS;
                ResourceLocation armorTexture = armorTexture(armor.getMaterial(), leggings);
                // Detect the dyeable-item interface rather than only vanilla leather material,
                // so compatible modded dyeable armor also receives its stored color.
                DyeableLeatherItem dyeableItem = armorStack.getItem() instanceof DyeableLeatherItem dyeable
                    ? dyeable : null;
                boolean hasCustomDye = dyeableItem != null && dyeableItem.hasCustomColor(armorStack);
                // Vanilla leather armor is white-tinted unless the stack has an explicit dye.
                int tint = hasCustomDye ? dyeableItem.getColor(armorStack) : 0xFFFFFF;
                renderArmorPart(armorModel, armor.getSlot(), pose,
                    buffers.getBuffer(RenderType.entityCutoutNoCull(armorTexture)), packedLight,
                    (tint >> 16 & 255) / 255.0F, (tint >> 8 & 255) / 255.0F, (tint & 255) / 255.0F);

                // Leather armor uses a second, untinted overlay texture to preserve
                // its details while the base layer receives the dye color.
                if (armor.getMaterial() == ArmorMaterials.LEATHER) {
                    ResourceLocation overlay = new ResourceLocation("minecraft",
                        "textures/models/armor/leather_layer_" + (leggings ? "2" : "1") + "_overlay.png");
                    renderArmorPart(armorModel, armor.getSlot(), pose,
                        buffers.getBuffer(RenderType.entityCutoutNoCull(overlay)), packedLight, 1F, 1F, 1F);
                }
                // Match vanilla's enchanted-item glint for armor stacks.
                if (armorStack.hasFoil()) {
                    renderArmorPart(armorModel, armor.getSlot(), pose,
                        buffers.getBuffer(RenderType.armorEntityGlint()), packedLight, 1F, 1F, 1F);
                }
            }
        }

        // Attach the optional hand-slot item to the model's actual right arm so
        // it follows independent arm rotation instead of floating at a fixed point.
        ItemStack held = be.inventory().getStackInSlot(CitizenBlockEntity.HAND_SLOT);
        if (!held.isEmpty() && handModel != null) {
            pose.pushPose();
            // Use the vanilla humanoid hand transform, which includes the torso/root
            // hierarchy as well as the arm pivot. Applying only rightArm here would
            // ignore body yaw and produce a floating item when the torso is rotated.
            handModel.translateToHand(HumanoidArm.RIGHT, pose);
            pose.mulPose(Axis.XP.rotationDegrees(-90.0F));
            pose.mulPose(Axis.YP.rotationDegrees(180.0F));
            pose.translate(1.0D / 16.0D, 0.125D, -0.625D);
            Minecraft.getInstance().getItemRenderer().renderStatic(
                held, ItemTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, packedLight,
                OverlayTexture.NO_OVERLAY, pose, buffers, be.getLevel(), 0);
            pose.popPose();
        }
        pose.popPose();

        // Render an optional name above the model, facing the camera.
        String displayName = be.displayName();
        if (displayName != null && !displayName.isBlank()) {
            Minecraft minecraft = Minecraft.getInstance();
            // Avoid rendering labels at extreme distances and place the label just
            // above the scaled model rather than leaving small citizens with a tall gap.
            net.minecraft.world.phys.Vec3 cameraPosition = minecraft.gameRenderer.getMainCamera().getPosition();
            net.minecraft.world.phys.Vec3 citizenCenter = net.minecraft.world.phys.Vec3.atCenterOf(be.getBlockPos());
            if (cameraPosition.distanceToSqr(citizenCenter) > 64.0D * 64.0D) return;
            Font font = minecraft.font;
            pose.pushPose();
            pose.translate(0.5D, Math.max(0.65D, 2.05D * be.scale()), 0.5D);
            pose.mulPose(minecraft.getEntityRenderDispatcher().cameraOrientation());
            pose.scale(-0.025F, -0.025F, 0.025F);
            Component label = Component.literal(displayName);
            float x = -font.width(label) / 2.0F;
            font.drawInBatch(label, x, 0.0F, 0xFFFFFF, false, pose.last().pose(),
                buffers, Font.DisplayMode.NORMAL, 0x40000000, packedLight);
            pose.popPose();
        }
    }
}
