package net.fybertech.modelcitizens.world;

import net.fybertech.modelcitizens.registry.ModBlockEntities;
import net.fybertech.modelcitizens.util.CitizenTextSanitizer;
import net.fybertech.modelcitizens.menu.CitizenMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemStackHandler;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CitizenBlockEntity extends BlockEntity implements MenuProvider {
    public static final int MAIN_SIZE = 36, ARMOR_SIZE = 4, HAND_SLOT = 40, TOTAL_SIZE = 41;
    public static final int POSE_SIZE = 7;
    private final ItemStackHandler inventory = new ItemStackHandler(TOTAL_SIZE) {
        @Override public void deserializeNBT(CompoundTag nbt) {
            // ItemStackHandler trusts the saved "Size" field and may resize its
            // internal list. CitizenMenu and the renderer rely on exactly 41 slots,
            // so normalize malformed/legacy NBT before handing it to the handler.
            CompoundTag safe = nbt.copy();
            safe.putInt("Size", TOTAL_SIZE);
            ListTag originalItems = nbt.getList("Items", Tag.TAG_COMPOUND);
            ListTag boundedItems = new ListTag();
            List<CompoundTag> duplicateSlots = new ArrayList<>();
            boolean[] occupied = new boolean[TOTAL_SIZE];
            for (int i = 0; i < originalItems.size(); i++) {
                CompoundTag item = originalItems.getCompound(i);
                if (!item.contains("Slot", Tag.TAG_BYTE) && !item.contains("Slot", Tag.TAG_INT)) continue;
                // Legacy inventory formats may encode Slot as a byte; getInt() returns
                // zero for a byte-valued tag, which would otherwise redirect every such
                // entry into slot zero. Read the actual stored NBT type explicitly.
                int slot = item.contains("Slot", Tag.TAG_INT) ? item.getInt("Slot") : item.getByte("Slot");
                if (slot < 0 || slot >= TOTAL_SIZE) continue;
                // Malformed NBT can contain multiple stacks for one slot. The vanilla
                // handler silently overwrites earlier entries, losing items. Keep the
                // first stack in its requested slot and relocate collisions to free main
                // inventory slots in a second pass, after all legitimate slots are known.
                if (occupied[slot]) {
                    duplicateSlots.add(item.copy());
                    continue;
                }
                occupied[slot] = true;
                boundedItems.add(normalizeSlotTag(item, slot));
            }
            for (CompoundTag duplicate : duplicateSlots) {
                int freeSlot = -1;
                // Prefer ordinary inventory slots so recovered equipment does not
                // unexpectedly become worn. If those are full, the dedicated hand
                // slot is still a valid general-purpose recovery destination.
                for (int slot = 0; slot < MAIN_SIZE; slot++) {
                    if (!occupied[slot]) { freeSlot = slot; break; }
                }
                if (freeSlot < 0 && !occupied[HAND_SLOT]) freeSlot = HAND_SLOT;
                if (freeSlot < 0) {
                    // Corrupt data can contain more stacks than the fixed inventory
                    // can represent. Do not overwrite a legitimate entry to make room.
                    continue;
                }
                occupied[freeSlot] = true;
                boundedItems.add(normalizeSlotTag(duplicate, freeSlot));
            }
            safe.put("Items", boundedItems);
            super.deserializeNBT(safe);
        }

        private CompoundTag normalizeSlotTag(CompoundTag item, int slot) {
            // Forge's ItemStackHandler deserializer reads Slot as a byte. Normalize
            // both accepted source encodings before delegating to the superclass.
            CompoundTag normalized = item.copy();
            normalized.putByte("Slot", (byte) slot);
            return normalized;
        }

        @Override public int getSlotLimit(int slot) {
            // Equipment slots represent one worn item even if a modded ArmorItem
            // unusually declares a stack size greater than one.
            return slot >= 36 && slot <= 39 ? 1 : super.getSlotLimit(slot);
        }

        @Override public boolean isItemValid(int slot, ItemStack stack) {
            // Enforce armor placement at the storage layer as well as in the menu,
            // so automation and other mods cannot insert mismatched armor pieces.
            if (slot >= 36 && slot <= 39) {
                if (!(stack.getItem() instanceof net.minecraft.world.item.ArmorItem armor)) return false;
                net.minecraft.world.entity.EquipmentSlot expected = switch (slot) {
                    case 36 -> net.minecraft.world.entity.EquipmentSlot.HEAD;
                    case 37 -> net.minecraft.world.entity.EquipmentSlot.CHEST;
                    case 38 -> net.minecraft.world.entity.EquipmentSlot.LEGS;
                    case 39 -> net.minecraft.world.entity.EquipmentSlot.FEET;
                    default -> throw new IllegalStateException("Unexpected armor slot");
                };
                // In Minecraft 1.20.1 ArmorItem exposes getSlot() returning EquipmentSlot.
                return armor.getSlot() == expected;
            }
            return slot >= 0 && slot < TOTAL_SIZE;
        }

        @Override protected void onContentsChanged(int slot) {
            setChanged();
            // The renderer reads armor and held-item slots directly from the block
            // entity. The 36 main inventory slots are synchronized by the open menu,
            // so broadcasting the full block-entity NBT for every ordinary stack
            // move would send large, redundant packets while players sort items.
            if (slot >= MAIN_SIZE) syncToClient();
        }
    };
    // A transient token distinguishes this exact block-entity instance from a
    // different citizen placed at the same coordinates after removal/replacement.
    private final UUID editorToken = UUID.randomUUID();
    private boolean suppressInventorySync;
    private String textureName = "";
    private String displayName = "";
    private int modelType = 0; // 0 = player, 1 = skeleton
    private float modelYaw = 0, scale = 1.0F;
    private final float[] pose = new float[POSE_SIZE]; // head yaw/pitch, body yaw, left/right arms, left/right legs (degrees)

    public CitizenBlockEntity(BlockPos pos, BlockState state) { super(ModBlockEntities.CITIZEN.get(), pos, state); }
    public ItemStackHandler inventory() { return inventory; }
    public String textureName() { return textureName; }
    public String displayName() { return displayName; }
    public int modelType() { return modelType; }
    public float modelYaw() { return modelYaw; }
    public float scale() { return scale; }
    public float[] pose() { return pose.clone(); }
    public UUID editorToken() { return editorToken; }

    private static String boundedText(String value, int maxLength) {
        return CitizenTextSanitizer.sanitizeSingleLine(value, maxLength);
    }

    private static String safeTextureId(String value) {
        String candidate = boundedText(value, 64).trim();
        return candidate.isEmpty() || net.fybertech.modelcitizens.util.CitizenTexturePathPolicy.isSafeTextureId(candidate)
            ? candidate : "";
    }

    public void setIdentity(String texture, String display, int type) {
        // Keep values bounded whether they arrive from a network packet, UI, or NBT.
        String nextTexture = safeTextureId(texture);
        String nextDisplay = boundedText(display, 64);
        int nextType = Math.max(0, Math.min(1, type));
        if (textureName.equals(nextTexture) && displayName.equals(nextDisplay) && modelType == nextType) return;
        textureName = nextTexture;
        displayName = nextDisplay;
        modelType = nextType;
        setChanged();
        syncToClient();
    }
    public void setPose(float yaw, float scale, float[] values) {
        float oldYaw = modelYaw, oldScale = this.scale;
        float[] oldPose = pose.clone();
        applyPose(yaw, scale, values);
        if (Float.compare(oldYaw, modelYaw) == 0 && Float.compare(oldScale, this.scale) == 0
                && java.util.Arrays.equals(oldPose, pose)) return;
        setChanged();
        syncToClient();
    }

    /** Apply all editor fields as one server-side state change and one client update. */
    public void applyEditorState(String texture, String display, int type,
                                 float yaw, float scale, float[] values) {
        String nextTexture = safeTextureId(texture);
        String nextDisplay = boundedText(display, 64);
        int nextType = Math.max(0, Math.min(1, type));
        boolean identityChanged = !textureName.equals(nextTexture)
            || !displayName.equals(nextDisplay) || modelType != nextType;
        float oldYaw = modelYaw, oldScale = this.scale;
        float[] oldPose = pose.clone();
        textureName = nextTexture;
        displayName = nextDisplay;
        modelType = nextType;
        applyPose(yaw, scale, values);
        if (!identityChanged && Float.compare(oldYaw, modelYaw) == 0
                && Float.compare(oldScale, this.scale) == 0 && java.util.Arrays.equals(oldPose, pose)) return;
        setChanged();
        syncToClient();
    }

    private void applyPose(float yaw, float scale, float[] values) {
        modelYaw = Float.isFinite(yaw) ? Math.max(-180.0F, Math.min(180.0F, yaw)) : 0.0F;
        this.scale = Float.isFinite(scale) ? Math.max(0.25F, Math.min(2.5F, scale)) : 1.0F;
        // A pose is a complete seven-value state, not a patch. Reset missing values
        // before copying so a short or null array cannot leave stale limb rotations
        // behind from the previous editor state.
        java.util.Arrays.fill(pose, 0.0F);
        if (values != null) {
            for (int i = 0; i < Math.min(pose.length, values.length); i++) {
                float value = Float.isFinite(values[i]) ? values[i] : 0.0F;
                pose[i] = Math.max(-180.0F, Math.min(180.0F, value));
            }
        }
    }
    private void syncToClient() {
        if (!suppressInventorySync && level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }
    @Override public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
    @Override public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }
    @Override public void handleUpdateTag(CompoundTag tag) {
        load(tag);
    }
    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inventory", inventory.serializeNBT());
        writeVisualData(tag);
    }

    /** Save appearance only for the placer item; inventory contents drop separately. */
    public CompoundTag saveVisualData() {
        CompoundTag tag = new CompoundTag();
        writeVisualData(tag);
        return tag;
    }

    /**
     * Initialize appearance from a placer without publishing intermediate block-entity
     * packets. Placement applies yaw after restoring the saved pose and publishes the
     * completed state once, avoiding multiple full-NBT updates for a newly placed block.
     */
    public void initializeForPlacement(CompoundTag visualData, float placementYaw) {
        if (visualData != null) {
            readVisualData(visualData);
        } else {
            textureName = "";
            displayName = "";
            modelType = 0;
        }
        float initialScale = visualData == null ? 1.0F : scale;
        float[] initialPose = visualData == null ? new float[POSE_SIZE] : pose.clone();
        applyPose(placementYaw, initialScale, initialPose);
        setChanged();
    }

    private void writeVisualData(CompoundTag tag) {
        tag.putString("TextureName", textureName);
        tag.putString("DisplayName", displayName);
        tag.putInt("ModelType", modelType);
        tag.putFloat("ModelYaw", modelYaw);
        tag.putFloat("Scale", scale);
        for (int i = 0; i < pose.length; i++) tag.putFloat("Pose" + i, pose[i]);
    }
    @Override public void load(CompoundTag tag) {
        // Deserializing the 41-slot handler can trigger onContentsChanged for each
        // restored stack. Suppress client block-update packets while loading a chunk
        // or applying an update tag; the caller will publish the completed state.
        suppressInventorySync = true;
        try {
            super.load(tag);
            if (tag.contains("Inventory", Tag.TAG_COMPOUND)) {
                inventory.deserializeNBT(tag.getCompound("Inventory"));
                normalizeLoadedArmorSlots();
            } else {
                // A malformed or older save may omit Inventory entirely. Do not keep
                // stacks from a previous state when this block entity instance is reused
                // for an update tag or a defensive recovery path.
                for (int slot = 0; slot < inventory.getSlots(); slot++) {
                    inventory.setStackInSlot(slot, ItemStack.EMPTY);
                }
            }
            readVisualData(tag);
        } finally {
            suppressInventorySync = false;
        }
    }

    private void readVisualData(CompoundTag tag) {
        textureName = safeTextureId(tag.getString("TextureName"));
        displayName = boundedText(tag.getString("DisplayName"), 64);
        modelType = Math.max(0, Math.min(1, tag.getInt("ModelType")));
        float savedYaw = tag.getFloat("ModelYaw");
        modelYaw = Float.isFinite(savedYaw) ? Math.max(-180.0F, Math.min(180.0F, savedYaw)) : 0.0F;
        float savedScale = tag.contains("Scale") ? tag.getFloat("Scale") : 1.0F;
        scale = Float.isFinite(savedScale) ? Math.max(0.25F, Math.min(2.5F, savedScale)) : 1.0F;
        for (int i = 0; i < pose.length; i++) {
            float saved = tag.getFloat("Pose" + i);
            pose[i] = Float.isFinite(saved) ? Math.max(-180.0F, Math.min(180.0F, saved)) : 0.0F;
        }
        // Migrate older saves that stored one mirrored leg-swing value.
        if (!tag.contains("Pose6")) pose[6] = -pose[5];
    }

    /**
     * Older or hand-edited saves can bypass ItemStackHandler#isItemValid. When a
     * malformed armor entry is found in the wrong equipment slot, move it into an
     * empty regular inventory slot where possible instead of rendering it as armor.
     * If the inventory is full, leave the stack untouched to avoid deleting items.
     */
    private void normalizeLoadedArmorSlots() {
        for (int slot = 36; slot <= 39; slot++) {
            ItemStack stack = inventory.getStackInSlot(slot);
            if (stack.isEmpty()) continue;
            net.minecraft.world.entity.EquipmentSlot expected = switch (slot) {
                case 36 -> net.minecraft.world.entity.EquipmentSlot.HEAD;
                case 37 -> net.minecraft.world.entity.EquipmentSlot.CHEST;
                case 38 -> net.minecraft.world.entity.EquipmentSlot.LEGS;
                case 39 -> net.minecraft.world.entity.EquipmentSlot.FEET;
                default -> throw new IllegalStateException("Unexpected armor slot");
            };
            if (stack.getItem() instanceof net.minecraft.world.item.ArmorItem armor
                    && armor.getSlot() == expected) continue;
            for (int mainSlot = 0; mainSlot < MAIN_SIZE; mainSlot++) {
                if (inventory.getStackInSlot(mainSlot).isEmpty()) {
                    inventory.setStackInSlot(slot, ItemStack.EMPTY);
                    inventory.setStackInSlot(mainSlot, stack);
                    break;
                }
            }
        }
    }

    /** Copy and clear all stored stacks without emitting one block update per slot. */
    public List<ItemStack> drainInventoryForRemoval() {
        List<ItemStack> drops = new ArrayList<>();
        suppressInventorySync = true;
        try {
            for (int slot = 0; slot < inventory.getSlots(); slot++) {
                ItemStack stack = inventory.getStackInSlot(slot);
                if (!stack.isEmpty()) {
                    drops.add(stack.copy());
                    inventory.setStackInSlot(slot, ItemStack.EMPTY);
                }
            }
        } finally {
            suppressInventorySync = false;
        }
        return drops;
    }

    @Override public Component getDisplayName() { return Component.literal(displayName.isBlank() ? "Model Citizen" : displayName); }
    @Override public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) { return new CitizenMenu(id, inv, this); }
}
