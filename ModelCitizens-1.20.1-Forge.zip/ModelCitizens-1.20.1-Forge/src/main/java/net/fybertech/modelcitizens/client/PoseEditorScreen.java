package net.fybertech.modelcitizens.client;

import net.fybertech.modelcitizens.network.ModNetwork;
import net.fybertech.modelcitizens.network.SetCitizenPosePacket;
import net.fybertech.modelcitizens.world.CitizenBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.fybertech.modelcitizens.util.CitizenTexturePathPolicy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;

public class PoseEditorScreen extends Screen {
    private final BlockPos pos;
    private float yaw, scale;
    private final float[] pose = new float[CitizenBlockEntity.POSE_SIZE];
    private int modelType;
    private String texture, displayName;
    private EditBox textureBox, nameBox;
    private boolean compactLayout;
    // Bake the preview models once per screen initialization instead of allocating
    // and baking a fresh model every frame while the editor is open.
    private PlayerModel<LivingEntity> previewPlayerModel;
    private SkeletonModel<Skeleton> previewSkeletonModel;

    public PoseEditorScreen(BlockPos pos, String texture, String displayName, int modelType, float yaw, float scale, float[] pose) {
        super(Component.translatable("screen.modelcitizens.editor.title"));
        this.pos = pos; this.texture = texture; this.displayName = displayName; this.modelType = modelType;
        this.yaw = yaw; this.scale = scale;
        if (pose != null) System.arraycopy(pose, 0, this.pose, 0, Math.min(pose.length, this.pose.length));
    }
    @Override protected void init() {
        var entityModels = Minecraft.getInstance().getEntityModels();
        previewPlayerModel = new PlayerModel<>(entityModels.bakeLayer(ModelLayers.PLAYER), false);
        previewSkeletonModel = new SkeletonModel<>(entityModels.bakeLayer(ModelLayers.SKELETON));
        compactLayout = width < 640 || height < 360;
        // Size both columns from the actual GUI width. At high GUI scales Minecraft
        // can expose fewer than 320 logical pixels; fixed 145px columns used to spill
        // past the right edge even though the preview had already been hidden.
        int columnGap = 10;
        int columnWidth = compactLayout ? Math.max(70, Math.min(145, (width - columnGap - 8) / 2)) : 145;
        int layoutWidth = columnWidth * 2 + columnGap;
        int left = Math.max(0, (width - layoutWidth) / 2);
        int secondColumn = left + columnWidth + columnGap;
        // Reserve the action row first, then adapt compact slider height and spacing
        // to the remaining vertical space. This keeps Save/Cancel reachable on short
        // logical GUI heights instead of placing the final controls off-screen.
        int actionY = compactLayout ? Math.min(280, Math.max(150, height - 24)) : 280;
        int compactSliderHeight = compactLayout
            ? Math.max(10, Math.min(20, (actionY - 86 - 12) / 5)) : 20;
        int compactSliderPitch = compactSliderHeight + 3;
        textureBox = new EditBox(font, left, 35, columnWidth, 20, Component.translatable("screen.modelcitizens.editor.texture"));
        textureBox.setMaxLength(64); textureBox.setValue(texture == null ? "" : texture);
        addRenderableWidget(textureBox);
        nameBox = new EditBox(font, secondColumn, 35, columnWidth, 20, Component.translatable("screen.modelcitizens.editor.name"));
        nameBox.setMaxLength(64); nameBox.setValue(displayName == null ? "" : displayName);
        addRenderableWidget(nameBox);
        addRenderableWidget(Button.builder(Component.translatable("screen.modelcitizens.editor.model", Component.translatable(modelType == 0 ? "screen.modelcitizens.model.player" : "screen.modelcitizens.model.skeleton")), b -> {
            modelType = 1 - modelType; b.setMessage(Component.translatable("screen.modelcitizens.editor.model", Component.translatable(modelType == 0 ? "screen.modelcitizens.model.player" : "screen.modelcitizens.model.skeleton")));
        }).bounds(left, 62, columnWidth, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.modelcitizens.editor.reset_pose"), b -> resetPose())
            .bounds(secondColumn, 62, columnWidth, 20).build());
        if (compactLayout) {
            // On small GUI scales a single vertical column pushes Save/Cancel off-screen.
            // Split the nine controls into two columns and reserve the bottom row for actions.
            addCompactSlider(left, 86, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.scale", scale, 0.25, 2.5, v -> scale = (float)v);
            addCompactSlider(left, 86 + compactSliderPitch, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.body_yaw", pose[2], -180, 180, v -> pose[2] = (float)v);
            addCompactSlider(left, 86 + compactSliderPitch * 2, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.head_yaw", pose[0], -180, 180, v -> pose[0] = (float)v);
            addCompactSlider(left, 86 + compactSliderPitch * 3, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.head_pitch", pose[1], -90, 90, v -> pose[1] = (float)v);
            addCompactSlider(left, 86 + compactSliderPitch * 4, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.left_arm", pose[3], -180, 180, v -> pose[3] = (float)v);
            addCompactSlider(secondColumn, 86, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.right_arm", pose[4], -180, 180, v -> pose[4] = (float)v);
            addCompactSlider(secondColumn, 86 + compactSliderPitch, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.left_leg", pose[5], -180, 180, v -> pose[5] = (float)v);
            addCompactSlider(secondColumn, 86 + compactSliderPitch * 2, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.right_leg", pose[6], -180, 180, v -> pose[6] = (float)v);
            addCompactSlider(secondColumn, 86 + compactSliderPitch * 3, columnWidth, compactSliderHeight, "screen.modelcitizens.editor.rotation", yaw, -180, 180, v -> yaw = (float)v);
        } else {
            addRenderableWidget(new ValueSlider(left, 86, layoutWidth, 20, "screen.modelcitizens.editor.scale", scale, 0.25, 2.5, v -> scale = (float)v));
            addRenderableWidget(new ValueSlider(left, 107, layoutWidth, 20, "screen.modelcitizens.editor.body_yaw", pose[2], -180, 180, v -> pose[2] = (float)v));
            addRenderableWidget(new ValueSlider(left, 128, layoutWidth, 20, "screen.modelcitizens.editor.head_yaw", pose[0], -180, 180, v -> pose[0] = (float)v));
            addRenderableWidget(new ValueSlider(left, 149, layoutWidth, 20, "screen.modelcitizens.editor.head_pitch", pose[1], -90, 90, v -> pose[1] = (float)v));
            addRenderableWidget(new ValueSlider(left, 170, layoutWidth, 20, "screen.modelcitizens.editor.left_arm", pose[3], -180, 180, v -> pose[3] = (float)v));
            addRenderableWidget(new ValueSlider(left, 191, layoutWidth, 20, "screen.modelcitizens.editor.right_arm", pose[4], -180, 180, v -> pose[4] = (float)v));
            addRenderableWidget(new ValueSlider(left, 212, layoutWidth, 20, "screen.modelcitizens.editor.left_leg", pose[5], -180, 180, v -> pose[5] = (float)v));
            addRenderableWidget(new ValueSlider(left, 233, layoutWidth, 20, "screen.modelcitizens.editor.right_leg", pose[6], -180, 180, v -> pose[6] = (float)v));
            addRenderableWidget(new ValueSlider(left, 254, layoutWidth, 20, "screen.modelcitizens.editor.rotation", yaw, -180, 180, v -> yaw = (float)v));
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.modelcitizens.save"), b -> save()).bounds(left, actionY, columnWidth, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.cancel"), b -> onClose()).bounds(secondColumn, actionY, columnWidth, 20).build());
    }
    private void addCompactSlider(int x, int y, int sliderWidth, int sliderHeight, String label,
                                  double value, double min, double max,
                                  java.util.function.DoubleConsumer changed) {
        addRenderableWidget(new ValueSlider(x, y, sliderWidth, sliderHeight, label, value, min, max, changed));
    }

    private void save() {
        texture = textureBox.getValue(); displayName = nameBox.getValue();
        ModNetwork.CHANNEL.sendToServer(new SetCitizenPosePacket(pos, yaw, scale, pose, texture, displayName, modelType));
        onClose();
    }

    /** Reset the seven articulation values while preserving other unsaved editor fields. */
    private void resetPose() {
        String currentTexture = textureBox.getValue();
        String currentName = nameBox.getValue();
        Minecraft.getInstance().setScreen(new PoseEditorScreen(
            pos, currentTexture, currentName, modelType, yaw, scale,
            new float[CitizenBlockEntity.POSE_SIZE]));
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(font, title, width/2, 12, 0xFFFFFF);
        // Long explanatory hints assume the desktop layout width; omit them in
        // compact mode so they cannot be clipped at the left/right screen edges.
        if (!compactLayout) {
            g.drawString(font, Component.translatable("screen.modelcitizens.editor.texture_hint"), width/2 - 150, 24, 0xAAAAAA);
            g.drawString(font, Component.translatable("screen.modelcitizens.editor.name_hint"), width/2 + 5, 24, 0xAAAAAA);
        }
        if (!compactLayout) {
            int previewX = width / 2 + 220;
            g.fill(previewX - 54, 40, previewX + 54, 270, 0xFF202020);
            g.drawCenteredString(font, Component.translatable("screen.modelcitizens.editor.preview"), previewX, 27, 0xFFFFFF);
            renderModelPreview(g, previewX, 125, partialTick);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void renderModelPreview(GuiGraphics graphics, int centerX, int centerY, float partialTick) {
        Minecraft minecraft = Minecraft.getInstance();
        PoseStack poseStack = graphics.pose();
        poseStack.pushPose();
        poseStack.translate(centerX, centerY + 35, 150);
        poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));
        poseStack.scale(34.0F * scale, -34.0F * scale, 34.0F * scale);

        ResourceLocation textureLocation = null;
        String requestedTexture = textureBox != null ? textureBox.getValue().trim() : texture;
        if (requestedTexture != null && !requestedTexture.isBlank()) {
            ResourceLocation parsed = ResourceLocation.tryParse(requestedTexture);
            if (isTextureResource(parsed) && minecraft.getResourceManager().getResource(parsed).isPresent()) textureLocation = parsed;
        }
        if (textureLocation == null) {
            textureLocation = modelType == 1
                ? new ResourceLocation("minecraft", "textures/entity/skeleton/skeleton.png")
                : DefaultPlayerSkin.getDefaultSkin();
        }

        MultiBufferSource.BufferSource buffers = minecraft.renderBuffers().bufferSource();
        if (modelType == 1) {
            applyPreviewPose(previewSkeletonModel);
            previewSkeletonModel.renderToBuffer(poseStack, buffers.getBuffer(RenderType.entityCutoutNoCull(textureLocation)),
                15728880, OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, 1F);
        } else {
            applyPreviewPose(previewPlayerModel);
            previewPlayerModel.renderToBuffer(poseStack, buffers.getBuffer(RenderType.entityCutoutNoCull(textureLocation)),
                15728880, OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, 1F);
        }
        buffers.endBatch();
        poseStack.popPose();
    }

    private static boolean isTextureResource(ResourceLocation location) {
        return location != null && CitizenTexturePathPolicy.isSafeTextureLocation(location.getNamespace(), location.getPath());
    }

    private void applyPreviewPose(HumanoidModel<?> model) {
        model.head.yRot = (float)Math.toRadians(pose[0]);
        model.head.xRot = (float)Math.toRadians(pose[1]);
        model.body.yRot = (float)Math.toRadians(pose[2]);
        model.leftArm.xRot = (float)Math.toRadians(pose[3]);
        model.rightArm.xRot = (float)Math.toRadians(pose[4]);
        model.leftLeg.xRot = (float)Math.toRadians(pose[5]);
        model.rightLeg.xRot = (float)Math.toRadians(pose[6]);
        // Humanoid body parts are siblings, so explicitly propagate torso yaw to
        // limbs just as vanilla humanoid animation does. Keep preview and world pose
        // in agreement, including the transform used by the held item.
        model.leftArm.yRot = model.body.yRot;
        model.rightArm.yRot = model.body.yRot;
        model.leftLeg.yRot = model.body.yRot;
        model.rightLeg.yRot = model.body.yRot;
    }
    @Override public boolean isPauseScreen() { return false; }

    private static class ValueSlider extends AbstractSliderButton {
        private final String labelKey; private final double min, max; private final java.util.function.DoubleConsumer changed;
        ValueSlider(int x, int y, int w, int h, String label, double value, double min, double max, java.util.function.DoubleConsumer changed) {
            super(x,y,w,h,Component.empty(), (value-min)/(max-min));
            this.labelKey=label; this.min=min; this.max=max; this.changed=changed; updateMessage();
        }
        private double value() { return min + value * (max-min); }
        @Override protected void updateMessage() { setMessage(Component.translatable(labelKey, String.format(java.util.Locale.ROOT, "%.1f", value()))); }
        @Override protected void applyValue() { changed.accept(value()); }
    }
}
