package net.fybertech.modelcitizens;

import net.fybertech.modelcitizens.registry.ModBlockEntities;
import net.fybertech.modelcitizens.registry.ModBlocks;
import net.fybertech.modelcitizens.registry.ModItems;
import net.fybertech.modelcitizens.registry.ModMenus;
import net.fybertech.modelcitizens.registry.ModTabs;
import net.fybertech.modelcitizens.network.ModNetwork;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraft.world.item.ShovelItem;
import net.fybertech.modelcitizens.network.EditorGrantManager;

@Mod(ModelCitizens.MODID)
public class ModelCitizens {
    public static final String MODID = "modelcitizens";

    public ModelCitizens() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.TYPES.register(bus);
        ModMenus.MENUS.register(bus);
        ModTabs.TABS.register(bus);
        ModNetwork.register();
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ModConfigSpecHolder.SPEC);
        MinecraftForge.EVENT_BUS.register(this);
    }

    /** Prevent non-shovel survival breaking and honor the optional invulnerability setting. */
    @SubscribeEvent
    public void onCitizenBreak(BlockEvent.BreakEvent event) {
        if (!event.getState().is(ModBlocks.CITIZEN.get())) return;
        if (event.getPlayer().isCreative()) return;
        if (ModConfigSpecHolder.INVULNERABLE.get()
                || !(event.getPlayer().getMainHandItem().getItem() instanceof ShovelItem)) {
            event.setCanceled(true);
        }
    }

    // Grants live only in server memory, but clear them on session transitions too.
    @SubscribeEvent
    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        EditorGrantManager.clear(event.getEntity());
    }

    @SubscribeEvent
    public void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        EditorGrantManager.clear(event.getEntity());
    }

    @SubscribeEvent
    public void onPlayerDeath(PlayerEvent.PlayerRespawnEvent event) {
        EditorGrantManager.clear(event.getEntity());
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        // The manager is static, so explicitly clear it between integrated-server
        // worlds and dedicated-server lifecycles even if a logout callback was missed.
        EditorGrantManager.clearAll();
    }
}
