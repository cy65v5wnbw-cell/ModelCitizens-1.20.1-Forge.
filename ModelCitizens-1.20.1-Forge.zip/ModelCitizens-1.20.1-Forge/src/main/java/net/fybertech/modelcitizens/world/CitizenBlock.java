package net.fybertech.modelcitizens.world;

import net.fybertech.modelcitizens.registry.ModBlockEntities;
import net.fybertech.modelcitizens.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.GameRules;

public class CitizenBlock extends BaseEntityBlock {
    public CitizenBlock(Properties properties) { super(properties.sound(SoundType.WOOD)); }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return ModBlockEntities.CITIZEN.get().create(pos, state); }

    /** Citizens are always explosion-resistant; survival removal is controlled by the legacy-style shovel rule. */
    @Override public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
        if (player.isCreative()) return 1.0F;
        if (net.fybertech.modelcitizens.ModConfigSpecHolder.INVULNERABLE.get()) return 0.0F;
        if (!(player.getMainHandItem().getItem() instanceof ShovelItem)) return 0.0F;
        return super.getDestroyProgress(state, player, level, pos);
    }

    /** Creative pick-block preserves the full citizen state, including its inventory. */
    @Override public ItemStack getCloneItemStack(BlockState state, HitResult target, LevelReader level, BlockPos pos, Player player) {
        ItemStack stack = new ItemStack(ModItems.CITIZEN.get());
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof CitizenBlockEntity citizen) {
            stack.getOrCreateTag().put("BlockEntityTag", citizen.saveWithoutMetadata());
        }
        return stack;
    }

    // The block entity renderer draws the actual citizen model; do not render the placeholder cube.
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.INVISIBLE; }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof CitizenBlockEntity citizen && !level.isClientSide) {
                // Respect the vanilla doTileDrops gamerule for both stored items and
                // the placer item. Clear the inventory either way so a removed block
                // entity cannot leave stale stacks behind if drops are disabled.
                boolean dropsEnabled = level.getGameRules().getBoolean(GameRules.RULE_DOBLOCKDROPS);
                // Capture appearance before draining the inventory. The placer item
                // intentionally keeps identity/pose only; contents are dropped once
                // as normal item stacks and therefore cannot be duplicated on re-place.
                net.minecraft.nbt.CompoundTag visualData = citizen.saveVisualData();
                // Drain the inventory in one suppressed-sync operation; otherwise
                // removing a fully equipped citizen emits up to 41 obsolete block
                // updates while the block entity is being removed.
                for (ItemStack stack : citizen.drainInventoryForRemoval()) {
                    if (dropsEnabled) popResource(level, pos, stack);
                }
                if (dropsEnabled && net.fybertech.modelcitizens.ModConfigSpecHolder.DROP_MODEL.get()) {
                    ItemStack placer = new ItemStack(ModItems.PLACER.get());
                    placer.getOrCreateTag().put("ModelCitizensData", visualData);
                    popResource(level, pos, placer);
                }
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof CitizenBlockEntity citizen) {
            if (player.isShiftKeyDown() && player.getItemInHand(hand).isEmpty()) {
                if (!player.mayBuild()) return InteractionResult.CONSUME;
                if (!level.isClientSide && !player.isCreative() && !net.fybertech.modelcitizens.ModConfigSpecHolder.MODIFY_IN_SURVIVAL.get()) return InteractionResult.CONSUME;
                if (!level.isClientSide) {
                    // Authorize on the server before opening the client-only screen. This
                    // avoids showing an editor that can never save when server config denies it.
                    net.fybertech.modelcitizens.network.EditorGrantManager.issue(player, level, citizen);
                    net.fybertech.modelcitizens.network.ModNetwork.CHANNEL.send(
                        net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> (net.minecraft.server.level.ServerPlayer) player),
                        new net.fybertech.modelcitizens.network.OpenCitizenEditorPacket(pos,
                            citizen.textureName(), citizen.displayName(), citizen.modelType(),
                            citizen.modelYaw(), citizen.scale(), citizen.pose()));
                }
                return InteractionResult.SUCCESS;
            }
            if (level.isClientSide) return InteractionResult.SUCCESS;
            player.openMenu(citizen, buf -> buf.writeBlockPos(pos));
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }
}
