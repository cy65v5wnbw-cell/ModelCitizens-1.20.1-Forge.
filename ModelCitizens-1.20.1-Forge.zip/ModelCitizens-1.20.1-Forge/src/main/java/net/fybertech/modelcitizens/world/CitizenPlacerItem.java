package net.fybertech.modelcitizens.world;

import net.fybertech.modelcitizens.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.nbt.CompoundTag;

public class CitizenPlacerItem extends Item {
    public CitizenPlacerItem(Properties properties) { super(properties); }
    @Override public InteractionResult useOn(net.minecraft.world.item.context.UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        // Check the destination before querying its state or attempting placement.
        // The level bounds cover legal build coordinates; the world border is a
        // separate restriction and must be enforced explicitly for custom items.
        if (!level.isInWorldBounds(pos) || !level.getWorldBorder().isWithinBounds(pos)) {
            return InteractionResult.FAIL;
        }
        // Do not call getBlockState() on the server until the destination chunk is
        // already loaded; a custom item must not force-load or generate chunks merely
        // because a player clicked toward an unloaded area.
        if (!level.isClientSide && !level.hasChunkAt(pos)) return InteractionResult.FAIL;
        BlockState previousState = level.getBlockState(pos);
        if (!previousState.canBeReplaced()) return InteractionResult.FAIL;
        if (context.getPlayer() != null
                && !context.getPlayer().mayUseItemAt(pos, context.getClickedFace(), context.getItemInHand())) {
            return InteractionResult.FAIL;
        }
        BlockState state = ModBlocks.CITIZEN.get().defaultBlockState();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        // A replaceable block supplied by another mod may still own a block entity.
        // Snapshot its data so the defensive rollback below restores more than just
        // the block state if citizen entity creation unexpectedly fails.
        BlockEntity previousBlockEntity = level.getBlockEntity(pos);
        CompoundTag previousBlockEntityTag = previousBlockEntity == null
            ? null : previousBlockEntity.saveWithoutMetadata();
        // Treat placement as a transaction: if the world refuses the block update,
        // report failure and leave the single-use placer untouched.
        if (!level.setBlock(pos, state, 3)) return InteractionResult.FAIL;
        if (!(level.getBlockEntity(pos) instanceof CitizenBlockEntity citizen)) {
            // A successful block-state write should create its registered block
            // entity. If registration/data is broken, roll back instead of leaving
            // an invisible citizen and consuming the only placer item.
            if (level.getBlockState(pos).is(state.getBlock())
                    && level.setBlock(pos, previousState, 3)
                    && previousBlockEntityTag != null) {
                BlockEntity restored = level.getBlockEntity(pos);
                if (restored != null) {
                    restored.load(previousBlockEntityTag);
                    restored.setChanged();
                    level.sendBlockUpdated(pos, previousState, previousState, 3);
                }
            }
            return InteractionResult.FAIL;
        }
        net.minecraft.nbt.CompoundTag itemTag = context.getItemInHand().getTag();
        net.minecraft.nbt.CompoundTag visualData = itemTag != null
                && itemTag.contains("ModelCitizensData", net.minecraft.nbt.Tag.TAG_COMPOUND)
            ? itemTag.getCompound("ModelCitizensData") : null;
        float placementYaw = context.getPlayer() == null ? 0.0F : context.getPlayer().getYRot();
        // Restore appearance and apply placement yaw in memory, then publish the
        // completed state once instead of sending intermediate full-NBT packets.
        citizen.initializeForPlacement(visualData, placementYaw);
        level.sendBlockUpdated(pos, state, state, 3);
        // Match vanilla placement feedback, but only after the block entity has
        // initialized successfully so rolled-back placements stay silent.
        level.playSound(null, pos, state.getSoundType().getPlaceSound(), SoundSource.BLOCKS,
            (state.getSoundType().getVolume() + 1.0F) / 2.0F, state.getSoundType().getPitch() * 0.8F);
        level.gameEvent(context.getPlayer(), GameEvent.BLOCK_PLACE, pos);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) context.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
