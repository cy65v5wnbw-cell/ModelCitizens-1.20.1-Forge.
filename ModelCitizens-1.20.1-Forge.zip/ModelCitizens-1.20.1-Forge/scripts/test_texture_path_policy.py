#!/usr/bin/env python3
"""Compile and exercise the production texture-path policy without Minecraft/Forge."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/main/java/net/fybertech/modelcitizens/util/CitizenTexturePathPolicy.java"

HARNESS = r'''import net.fybertech.modelcitizens.util.CitizenTexturePathPolicy;

public final class CitizenTexturePathPolicyTest {
    private static void check(boolean expected, String path) {
        boolean actual = CitizenTexturePathPolicy.isSafeTexturePath(path);
        if (expected != actual) {
            throw new AssertionError("path [" + path + "]: expected " + expected + ", got " + actual);
        }
    }

    private static void checkId(boolean expected, String id) {
        boolean actual = CitizenTexturePathPolicy.isSafeTextureId(id);
        if (expected != actual) {
            throw new AssertionError("resource ID [" + id + "]: expected " + expected + ", got " + actual);
        }
    }

    private static void checkLocation(boolean expected, String namespace, String path) {
        boolean actual = CitizenTexturePathPolicy.isSafeTextureLocation(namespace, path);
        if (expected != actual) {
            throw new AssertionError("location [" + namespace + ":" + path + "]: expected " + expected + ", got " + actual);
        }
    }

    public static void main(String[] args) {
        check(true, "textures/entity/citizen.png");
        check(true, "textures/modid/subfolder/skin_2.png");
        check(false, null);
        check(false, "");
        check(false, "entity/citizen.png");
        check(false, "textures/entity/citizen.jpg");
        check(false, "textures/entity/citizen.json");
        check(false, "textures/../citizen.png");
        check(false, "textures/entity/../citizen.png");
        check(false, "textures/./entity.png");
        check(false, "textures//entity/citizen.png");
        check(false, "textures/entity\\\\citizen.png");
        check(false, "../textures/entity/citizen.png");
        check(false, "textures/entity/MyCitizen.png");
        check(false, "textures/entity/my citizen.png");
        check(false, "textures/entity/citizén.png");
        check(false, "textures/entity/.png");
        check(false, "textures/entity/..");
        checkId(true, "modelcitizens:textures/entity/citizen.png");
        checkId(true, "textures/entity/citizen.png");
        checkId(false, "modelcitizens:models/block/citizen.json");
        checkId(false, "../textures/entity/citizen.png");
        checkId(false, "ModelCitizens:textures/entity/citizen.png");
        checkId(false, "modelcitizens:textures/entity/MyCitizen.png");
        checkId(false, "modelcitizens:textures/entity/citizen.png:extra");
        checkId(false, "");
        checkId(false, null);
        checkLocation(true, "modelcitizens", "textures/entity/citizen.png");
        checkLocation(false, "ModelCitizens", "textures/entity/citizen.png");
        checkLocation(false, "mod id", "textures/entity/citizen.png");
        System.out.println("Production texture policy: 31 behavioral tests passed.");
    }
}
'''


class TexturePathPolicyTests(unittest.TestCase):
    def test_production_java_texture_policy(self) -> None:
        javac, java = shutil.which("javac"), shutil.which("java")
        if not javac or not java:
            self.skipTest("JDK not available; pure-Java texture policy could not be executed")
        with tempfile.TemporaryDirectory(prefix="modelcitizens-texture-test-") as temp:
            temp_path = Path(temp)
            harness = temp_path / "CitizenTexturePathPolicyTest.java"
            harness.write_text(HARNESS, encoding="utf-8")
            subprocess.run(
                [javac, "-encoding", "UTF-8", "-d", str(temp_path), str(SOURCE), str(harness)],
                check=True, capture_output=True, text=True,
            )
            result = subprocess.run(
                [java, "-cp", str(temp_path), "CitizenTexturePathPolicyTest"],
                check=True, capture_output=True, text=True,
            )
            self.assertIn("31 behavioral tests passed", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
