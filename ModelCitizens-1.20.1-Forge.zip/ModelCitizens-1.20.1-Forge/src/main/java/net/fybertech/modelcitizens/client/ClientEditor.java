package net.fybertech.modelcitizens.client;

import net.fybertech.modelcitizens.world.CitizenBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public final class ClientEditor {
    public static void open(BlockPos pos, CitizenBlockEntity citizen) {
        if (citizen == null) return;
        open(pos, citizen.textureName(), citizen.displayName(), citizen.modelType(),
            citizen.modelYaw(), citizen.scale(), citizen.pose());
    }

    /** Opens from a server-approved editor packet, so client config cannot bypass server permissions. */
    public static void open(BlockPos pos, String texture, String displayName, int modelType,
                            float yaw, float scale, float[] pose) {
        Minecraft.getInstance().setScreen(new PoseEditorScreen(
            pos, texture, displayName, modelType, yaw, scale, pose));
    }
    private ClientEditor() {}
}
