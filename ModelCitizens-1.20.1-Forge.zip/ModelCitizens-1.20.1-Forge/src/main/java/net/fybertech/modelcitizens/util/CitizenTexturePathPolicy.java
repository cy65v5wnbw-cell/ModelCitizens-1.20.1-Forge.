package net.fybertech.modelcitizens.util;

/** Shared path policy for custom citizen textures in both the editor and world renderer. */
public final class CitizenTexturePathPolicy {
    private CitizenTexturePathPolicy() { }

    /**
     * Accept only canonical Minecraft-style PNG paths beneath the texture root.
     * Resource existence checks are deliberately performed by the Minecraft caller;
     * this helper can be tested without Forge.
     */
    public static boolean isSafeTextureLocation(String namespace, String path) {
        if (namespace == null || namespace.isEmpty()) return false;
        for (int i = 0; i < namespace.length(); i++) {
            char c = namespace.charAt(i);
            boolean safe = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                || c == '_' || c == '-' || c == '.';
            if (!safe) return false;
        }
        return isSafeTexturePath(path);
    }

    /**
     * Validate a resource ID string without loading Minecraft classes. An omitted
     * namespace follows ResourceLocation's default namespace, "minecraft".
     */
    public static boolean isSafeTextureId(String value) {
        if (value == null || value.isEmpty()) return false;
        int colon = value.indexOf(':');
        if (colon != value.lastIndexOf(':')) return false;
        String namespace = colon < 0 ? "minecraft" : value.substring(0, colon);
        String path = colon < 0 ? value : value.substring(colon + 1);
        return isSafeTextureLocation(namespace, path);
    }

    /** Accept only canonical lowercase ASCII PNG paths below textures/. */
    public static boolean isSafeTexturePath(String path) {
        if (path == null || !path.startsWith("textures/") || !path.endsWith(".png")
                || path.indexOf('\\') >= 0 || path.contains("//")) {
            return false;
        }

        // Minecraft resource paths use lowercase ASCII and a small safe alphabet.
        // Reject non-canonical segments as well as traversal, including a lone dot.
        String[] segments = path.split("/", -1);
        if (segments.length < 2 || !"textures".equals(segments[0])) return false;
        // Require a non-empty filename stem before the .png extension.
        if (segments[segments.length - 1].length() <= 4) return false;
        for (int i = 1; i < segments.length; i++) {
            String segment = segments[i];
            if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment)) return false;
            for (int j = 0; j < segment.length(); j++) {
                char c = segment.charAt(j);
                boolean safe = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                    || c == '_' || c == '-' || c == '.';
                if (!safe) return false;
            }
        }
        return true;
    }
}
