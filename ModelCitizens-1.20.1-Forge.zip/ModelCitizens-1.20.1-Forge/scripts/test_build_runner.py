#!/usr/bin/env python3
"""Guardrails for the reproducible local build entry points."""
from __future__ import annotations
import shutil
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SH = ROOT / "scripts/build_mod.sh"
PS = ROOT / "scripts/build_mod.ps1"
DOCKER = ROOT / "scripts/build_mod_docker.sh"

class BuildRunnerTests(unittest.TestCase):
    def test_posix_script_passes_shell_syntax_check(self) -> None:
        bash = shutil.which("bash")
        if not bash:
            self.skipTest("bash is not installed")
        result = subprocess.run([bash, "-n", str(SH)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_build_uses_fixed_gradle_version_and_official_checksum(self) -> None:
        script = SH.read_text(encoding="utf-8")
        self.assertIn('GRADLE_VERSION="8.8"', script)
        self.assertIn('https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip', script)
        self.assertIn('EXPECTED_SHA="$(curl --fail --location --retry 2 "$CHECKSUM_URL"', script)
        self.assertIn('sha256sum "$DIST_ZIP"', script)
        self.assertIn('refusing to execute it', script)

    def test_build_requires_jdk_17_and_runs_checks_first(self) -> None:
        script = SH.read_text(encoding="utf-8")
        self.assertLess(script.index('python3 scripts/run_checks.py'), script.index('JAVA_VERSION_LINE='))
        self.assertIn('JDK 17', script)
        self.assertIn('exec "$GRADLE_BIN" --no-daemon clean build', script)

    def test_docker_build_is_pinned_and_runs_checks_before_container(self) -> None:
        script = DOCKER.read_text(encoding="utf-8")
        self.assertIn('IMAGE="gradle:8.8-jdk17"', script)
        self.assertLess(script.index('python3 scripts/run_checks.py'), script.index('docker info'))
        self.assertIn('docker run --rm', script)
        self.assertIn('--user "$(id -u):$(id -g)"', script)
        self.assertIn('--no-daemon clean build', script)
        bash = shutil.which("bash")
        if bash:
            result = subprocess.run([bash, "-n", str(DOCKER)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_windows_entry_point_has_same_build_guards(self) -> None:
        script = PS.read_text(encoding="utf-8")
        self.assertIn('python scripts/run_checks.py', script)
        self.assertIn("$GradleVersion = '8.8'", script)
        self.assertIn('Get-FileHash -Path $Zip -Algorithm SHA256', script)
        self.assertIn('& $GradleExe --no-daemon clean build', script)

if __name__ == "__main__":
    unittest.main(verbosity=2)
