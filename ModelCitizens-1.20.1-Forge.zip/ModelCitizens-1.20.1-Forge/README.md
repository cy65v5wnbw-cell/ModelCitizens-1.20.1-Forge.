# Model Citizens — community port for Minecraft 1.20.1 Forge

A source-level community port of the legacy **Model Citizens** concept for Minecraft 1.20.1 and Forge 47.3.x. The project is not yet a verified release: it still needs a successful ForgeGradle build and an in-game smoke test before a compiled JAR can be called ready.

## Current feature set

- Place a custom humanoid citizen block using the placer item.
- The custom placer rejects destinations outside legal world bounds or beyond the world border before inspecting or changing the target block. If the server rejects the block update, or the registered citizen block entity is unexpectedly missing after placement, the operation reports failure and preserves the placer; the missing-entity path restores the previous target block state.
- Choose a player-style or skeleton-style humanoid model. The renderer expands its frustum-culling bounds based on model scale so tall/larger citizens and their name labels do not vanish prematurely at screen edges.
- Configure display name, texture resource, model yaw, scale, and seven pose values.
- Store a 41-slot inventory: 36 general slots, four equipment slots, and one rendered hand slot.
- Render supported armor and an item in the right hand; dyed leather armor and item glint are handled by the custom renderer. Armor trims and every modded armor rendering feature are not yet guaranteed.
- Save/load citizen state with block-entity NBT and synchronize changes to tracking clients. Placer initialization batches saved appearance and placement yaw before sending one final block-entity update, avoiding redundant packets.
- Copy citizen state through the creative pick-block operation; the placer item intentionally carries visual settings, not the citizen's inventory. Placing a placer item turns the model toward the placing player while preserving its saved pose and scale.
- Drop inventory on block removal subject to Minecraft's `doTileDrops` gamerule; the placer drop and survival editing/insertion behavior are configurable.
- Authorize pose-editor updates on the server using a short-lived grant tied to the player, dimension, block position, and exact block-entity instance.
- Sanitize display text and validate texture resource paths before the client attempts to use them.
- The custom 41-slot inventory screen lays out armor, citizen inventory, held item, and player inventory with aligned slot outlines, and suppresses the vanilla inventory heading so it does not overlap the player slots; English and Russian language resources are included.
- The pose editor switches to a compact two-column control layout at small GUI resolutions, sizes the columns to the available logical width (down to 150 pixels), adapts slider height and spacing to short logical GUI heights, keeps Save/Cancel visible near the bottom, omits long hints that would clip in compact mode, and hides the 3D preview when it would be clipped off-screen.

## Requirements

- Minecraft **1.20.1**
- Minecraft Forge **47.3.0** (the build declares `1.20.1-47.3.0`)
- JDK **17** for the ForgeGradle build
- Gradle **8.8** (or run the same Gradle version in CI)
- Internet access during the first build so Gradle can download ForgeGradle and Minecraft/Forge dependencies

## Build

From the project root, run the build helper on Linux/macOS:

```sh
bash scripts/build_mod.sh
```

On Windows PowerShell, run:

```powershell
.\scripts\build_mod.ps1
```

Both helpers run source/resource checks first, require JDK 17, use Gradle 8.8, and then execute `clean build`. If Gradle is not installed, the helper downloads the official Gradle 8.8 distribution and verifies its published SHA-256 before executing it. The first build still needs internet access to download Gradle and Forge dependencies. You can also run `gradle --no-daemon clean build` directly if Gradle 8.8 and JDK 17 are already configured.

The compiled mod JAR, if the build succeeds, will be in `build/libs/`. The `jar` task is configured to run ForgeGradle's `reobfJar` step as well.

If the host does not have JDK 17 or Gradle configured but Docker is available, use the containerized build:

```bash
bash scripts/build_mod_docker.sh
```

This runs the checks on the host and builds inside the pinned `gradle:8.8-jdk17` image. Docker must be running, and the first container build needs network access to fetch the image and Forge/Minecraft dependencies. The repository is mounted at `/workspace`; the resulting JAR remains in the host's `build/libs/` directory.

For quick local source/resource checks without downloading Forge dependencies:

```sh
python3 scripts/run_checks.py
```

This command validates project structure/resources and automatically discovers and runs every `scripts/test_*.py` regression suite, so new suites are included without maintaining a duplicate command list. The pure-Java text and texture policy tests compile their production utility classes with `javac`; the source-inspection tests do **not** compile the mod against Forge. A successful static-check run is not proof that the complete mod compiles or launches.

GitHub Actions runs `scripts/build_mod.sh` with JDK 17 and Gradle 8.8. A successful CI build should publish the JAR as the `modelcitizens-forge-1.20.1` workflow artifact.

## Texture resource format

The texture field accepts a Minecraft resource location, for example:

```text
modelcitizens:textures/entity/my_citizen.png
```

The resource must exist on the client and its path must be a canonical lowercase ASCII PNG path below `textures/`. Place custom textures in a resource pack or mod resource namespace. Arbitrary files, traversal segments (`..`), backslashes, uppercase names, and non-PNG paths are rejected. This port does not fetch player skins from Mojang by username; use an actual resource location instead.

## Configuration

Forge's common config is generated under `config/modelcitizens-common.toml` after the mod is loaded:

- `general.dropModel` — drop a placer item when a citizen is broken (default `true`).
- `general.invulnerable` — prevent survival players from breaking citizens (default `false`; creative mode can still remove them). Citizens are explosion-resistant regardless of this setting.
- `general.modifyInSurvival` — allow pose/configuration editing in survival (default `true`).
- `general.survivalCanInsert` — allow inserting items into the citizen inventory in survival (default `true`).

## Current validation status

The included checks cover source structure, resource JSON and model references, translations, editor packet authorization, inventory recovery, state transfer, transactional placement and world bounds, text sanitization, texture-path policy, and menu-slot/background alignment. They are useful regression guards but cannot replace ForgeGradle compilation, launching a client/server, and testing rendering and menu behavior in-game. Until those steps pass, treat this as a development source snapshot rather than a finished binary release.

## Legacy reference

`legacy-readme.txt` preserves the supplied documentation for the Minecraft 1.7.10 version. This project is a community port, and behavior from the old version may differ where Minecraft/Forge APIs changed.


### Custom texture resource validation

Custom citizen textures are accepted only as canonical Minecraft resource IDs whose namespace uses lowercase resource characters and whose path is a lowercase ASCII PNG under `textures/` (for example `modelcitizens:textures/entity/citizen.png`). The same policy is applied to editor submissions and saved block-entity data; invalid IDs are cleared and the renderer falls back to the model's default texture. The policy does not download files or accept external URLs.


### Regression-test discovery

`scripts/run_checks.py` discovers all `scripts/test_*.py` files automatically. The validator itself runs first; each discovered suite then runs as a separate process, and the command stops at the first failure. This prevents a newly added regression suite from silently being omitted from local and CI checks.


### Narrow-window editor layout

The compact editor computes its column width from the current logical screen width instead of assuming two fixed 145-pixel columns. The regression suite exercises the layout arithmetic at widths from 150 to 639 logical pixels, including very narrow layouts, so both columns and action buttons stay inside the screen bounds. This remains a source-level layout test; a Minecraft client smoke test is still required.


### Placement transaction hardening

The placer now treats block-state placement and block-entity initialization as one logical operation. If the state write fails, the item is not consumed. If the state write succeeds but the expected `CitizenBlockEntity` is absent, the code restores the previous target state and returns failure before touching the item stack. Regression checks verify bounds-before-state access and rollback-before-consumption ordering. These tests inspect source ordering; the behavior still needs an in-game Forge test.


### Avoiding accidental chunk loads during placement

The custom placer checks server-side chunk availability before reading the destination block state. This avoids probing an unloaded destination through `getBlockState()` before the explicit loaded-chunk guard. A regression test checks that this guard remains ahead of both destination-state and block-entity reads.


### Placement feedback

The custom placer now emits the block's normal placement sound and a `BLOCK_PLACE` game event only after the citizen block entity has initialized successfully. Failed writes and rollback paths do not emit success feedback or consume the placer. A source-level regression test checks this ordering; in-game sound and event behavior still require a Forge runtime test.


### Inventory and state synchronization

The 36 main inventory slots use normal menu synchronization. Only armor and held-item changes broadcast block-entity data needed by the renderer, avoiding redundant full-inventory packets while sorting items. Identity and pose setters also compare their sanitized, normalized values with the current state and skip marking the block entity dirty or sending a block update when an editor packet does not change anything. Combined editor saves remain atomic and send at most one update. The regression suite checks these no-op guards at source level; packet counts and behavior still need a Forge runtime test.

### Placement rollback hardening

The placer now snapshots the NBT of a replaceable target block entity before changing the world. If citizen block-entity initialization fails and the operation rolls back, it restores the previous block state and, when present, reloads the prior block-entity data and republishes the restored state. This is a defensive path for replaceable blocks supplied by other mods; normal successful placement is unchanged.
