package net.fybertech.modelcitizens.client;

import net.fybertech.modelcitizens.registry.ModMenus;
import net.minecraftforge.client.event.RegisterMenuScreensEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.fybertech.modelcitizens.ModelCitizens;

@Mod.EventBusSubscriber(modid = ModelCitizens.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.CITIZEN.get(), CitizenScreen::new);
    }
    private ClientSetup() {}
}
