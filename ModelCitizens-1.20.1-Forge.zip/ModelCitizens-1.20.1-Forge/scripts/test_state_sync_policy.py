#!/usr/bin/env python3
"""Regression checks for avoiding redundant citizen block-entity updates."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/main/java/net/fybertech/modelcitizens/world/CitizenBlockEntity.java"


class StateSyncPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SOURCE.read_text(encoding="utf-8")

    def method(self, signature: str, next_signature: str) -> str:
        start = self.source.index(signature)
        end = self.source.index(next_signature, start)
        return self.source[start:end]

    def test_identity_setter_returns_without_dirtying_unchanged_state(self) -> None:
        method = self.method("public void setIdentity(", "public void setPose(")
        self.assertIn("textureName.equals(nextTexture)", method)
        self.assertIn("displayName.equals(nextDisplay)", method)
        self.assertIn("modelType == nextType) return;", method)
        self.assertEqual(method.count("syncToClient();"), 1)

    def test_pose_setter_compares_normalized_pose_before_sync(self) -> None:
        method = self.method("public void setPose(", "/** Apply all editor fields")
        self.assertIn("float[] oldPose = pose.clone();", method)
        self.assertIn("java.util.Arrays.equals(oldPose, pose)", method)
        self.assertIn("return;", method)
        self.assertEqual(method.count("syncToClient();"), 1)


    def test_placement_initializer_does_not_broadcast_intermediate_updates(self) -> None:
        method = self.method("public void initializeForPlacement(", "private void writeVisualData(")
        self.assertIn("readVisualData(visualData);", method)
        self.assertIn("applyPose(placementYaw, initialScale, initialPose);", method)
        self.assertIn("setChanged();", method)
        self.assertNotIn("syncToClient();", method)

    def test_editor_commit_stays_atomic_and_skips_identical_state(self) -> None:
        method = self.method("public void applyEditorState(", "private void applyPose(")
        self.assertIn("boolean identityChanged", method)
        self.assertIn("java.util.Arrays.equals(oldPose, pose)", method)
        self.assertEqual(method.count("syncToClient();"), 1)
        self.assertEqual(method.count("setChanged();"), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
