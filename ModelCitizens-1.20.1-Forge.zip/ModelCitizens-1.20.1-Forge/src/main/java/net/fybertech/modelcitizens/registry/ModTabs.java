package net.fybertech.modelcitizens.registry;

import net.fybertech.modelcitizens.ModelCitizens;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Creative tab for the mod's placeable citizen and its editor/placer item. */
public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ModelCitizens.MODID);

    public static final RegistryObject<CreativeModeTab> MODEL_CITIZENS = TABS.register("model_citizens", () ->
        CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.modelcitizens"))
            .icon(() -> new ItemStack(ModItems.PLACER.get()))
            .displayItems((parameters, output) -> {
                output.accept(ModItems.CITIZEN.get());
                output.accept(ModItems.PLACER.get());
            })
            .build());

    private ModTabs() {}
}
